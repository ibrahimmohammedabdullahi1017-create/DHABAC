
import React, { useState, useEffect } from 'react';
import { UserRole, AppState, Student, Teacher, AttendanceRecord, ExamResult, SchoolClass, ReadingMaterial, SchoolSettings } from './types';
import Sidebar from './components/Layout/Sidebar';
import AdminDashboard from './components/Admin/AdminDashboard';
import StudentView from './components/Student/StudentView';
import AITeacher from './components/Student/AITeacher';
import AttendanceTracker from './components/Shared/AttendanceTracker';
import StudentAttendanceView from './components/Student/StudentAttendanceView';
import ResultEntry from './components/Teacher/ResultEntry';
import TeacherDashboard from './components/Teacher/TeacherDashboard';
import LessonManagement from './components/Teacher/LessonManagement';
import LessonMonitor from './components/Admin/LessonMonitor';
import ReadingSchedule from './components/Student/ReadingSchedule';
import AttendanceManagement from './components/Admin/AttendanceManagement';
import RegistrationManagement from './components/Admin/RegistrationManagement';
import ResultManagement from './components/Admin/ResultManagement';
import StudentList from './components/Admin/StudentList';
import StudentManagement from './components/Admin/StudentManagement';
import TeacherManagement from './components/Admin/TeacherManagement';
import ClassManagement from './components/Admin/ClassManagement';
import SettingsManagement from './components/Admin/SettingsManagement';
import BackupManagement from './components/Admin/BackupManagement';
import AdminManagement from './components/Admin/AdminManagement';
import StudentAlbum from './components/Admin/StudentAlbum';
import ProfileView from './components/Shared/ProfileView';
import RegistrationForm from './components/Auth/RegistrationForm';
import { SchoolStorage } from './services/storage';
import { AuthService } from './services/authService';
import { AttendanceService } from './services/attendanceService';
import { supabase } from './services/supabase';
import { isTabAuthorized } from './services/permissions';
import { Lock, User as UserIcon, ShieldAlert, GraduationCap, Menu, UserPlus, Loader2, Phone, ChevronRight, LayoutDashboard } from 'lucide-react';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>(() => SchoolStorage.load());
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loginForm, setLoginForm] = useState({ id: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [initializing, setInitializing] = useState(true);
  const [view, setView] = useState<'login' | 'register'>('login');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [activeQuizLesson, setActiveQuizLesson] = useState<ReadingMaterial | null>(null);

  useEffect(() => {
    const initAuth = async () => {
      try {
        const user = await AuthService.getCurrentUser();
        if (user) {
          setState(prev => ({ ...prev, currentUser: user as any }));
        }
      } catch (err) {
        console.error("Auth init error:", err);
      } finally {
        // Ensure the app shows something even if initialization takes time or fails
        setTimeout(() => setInitializing(false), 800);
      }
    };

    initAuth();

    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session) {
        const user = await AuthService.getCurrentUser();
        if (user) setState(prev => ({ ...prev, currentUser: user as any }));
      } else if (event === 'SIGNED_OUT') {
        setState(prev => ({ ...prev, currentUser: null }));
        setActiveTab('dashboard');
      }
    });

    return () => {
      authListener.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    SchoolStorage.save(state);
    const root = document.documentElement;
    root.style.setProperty('--primary-color', state.settings.primaryColor);
    root.style.setProperty('--secondary-color', state.settings.secondaryColor);
  }, [state]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { profile } = await AuthService.signIn(loginForm.id, loginForm.password);
      setState(prev => ({ ...prev, currentUser: profile }));
    } catch (err: any) {
      setError(err.message || 'ID Number ama Password khaldan');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (data: any) => {
    setLoading(true);
    setError('');
    
    const studentIds = state.students
      .map(s => {
        const match = s.idNumber.match(/(\d+)/);
        return match ? parseInt(match[0]) : 0;
      })
      .filter(id => id > 0);
    
    const maxId = studentIds.length > 0 ? Math.max(...studentIds) : 1000;
    const providedIdNumMatch = data.idNumber.match(/(\d+)/);
    const providedIdNum = providedIdNumMatch ? parseInt(providedIdNumMatch[0]) : 0;
    
    const isSequential = providedIdNum === maxId + 1;
    const status = isSequential ? 'approved' : 'pending';

    try {
      const { profile } = await AuthService.signUp({
        name: data.name,
        idNumber: data.idNumber,
        className: data.className,
        password: data.password,
        role: UserRole.STUDENT,
        status: status
      });
      
      const newStudent: Student = {
        id: profile.db_id || `s-reg-${Date.now()}`,
        idNumber: data.idNumber,
        name: data.name,
        role: UserRole.STUDENT,
        className: data.className,
        status: status,
        password: data.password
      };

      setState(prev => ({ ...prev, students: [...prev.students, newStudent] }));

      if (status === 'approved') {
        setState(prev => ({ ...prev, currentUser: profile }));
      }
      
      return status;
    } catch (err: any) {
      setError(err.message || 'Cilad ayaa dhacday intii diwaangelintu socotay.');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await AuthService.signOut();
    setState(prev => ({ ...prev, currentUser: null }));
    setActiveTab('dashboard');
    setLoginForm({ id: '', password: '' });
    setIsSidebarOpen(false);
  };

  if (initializing) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center space-y-6 animate-pulse">
          <div className="w-20 h-20 bg-blue-900 rounded-[2.5rem] flex items-center justify-center text-white shadow-2xl">
            <GraduationCap size={48} />
          </div>
          <div className="text-center">
            <p className="text-blue-900 font-black text-xl tracking-tighter">ALNACIIM ACADEMY</p>
            <p className="text-slate-400 font-black uppercase text-[10px] tracking-[0.3em] mt-1">Nidaamka Dhabac Professional</p>
          </div>
          <Loader2 className="animate-spin text-blue-900 opacity-50" size={24} />
        </div>
      </div>
    );
  }

  if (!state.currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-slate-100 bg-[radial-gradient(circle_at_top_right,_var(--primary-color),_transparent_40%),radial-gradient(circle_at_bottom_left,_var(--secondary-color),_transparent_40%)]">
        <div className="max-w-md w-full bg-white/95 backdrop-blur-2xl rounded-[3rem] shadow-[0_32px_128px_-16px_rgba(0,0,0,0.15)] overflow-hidden border border-white">
          {view === 'login' ? (
            <>
              <div className="p-10 text-center">
                 <div className="flex justify-center mb-6">
                    {state.settings.logoUrl ? (
                      <img src={state.settings.logoUrl} alt="Logo" className="w-24 h-24 object-contain rounded-3xl shadow-xl border-4 border-white" />
                    ) : (
                      <div className="w-20 h-20 rounded-[2rem] flex items-center justify-center shadow-xl text-white" style={{ backgroundColor: 'var(--primary-color)' }}>
                        <GraduationCap size={44} />
                      </div>
                    )}
                 </div>
                 <h1 className="text-4xl font-black tracking-tighter mb-1" style={{ color: 'var(--primary-color)' }}>{state.settings.systemName}</h1>
                 <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em]">{state.settings.schoolName}</p>
              </div>
              
              <form onSubmit={handleLogin} className="px-10 pb-10 space-y-5">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">ID Number / Role Number</label>
                  <div className="relative group">
                    <UserIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-300 group-focus-within:text-blue-600 transition-colors" size={18} />
                    <input 
                      type="text" required placeholder="Tusaale: AL-1001"
                      className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none font-bold text-slate-700 transition-all"
                      value={loginForm.id}
                      onChange={e => setLoginForm({...loginForm, id: e.target.value})}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Password</label>
                  <div className="relative group">
                    <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-300 group-focus-within:text-blue-600 transition-colors" size={18} />
                    <input 
                      type="password" required placeholder="••••••••"
                      className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none font-bold text-slate-700 transition-all"
                      value={loginForm.password}
                      onChange={e => setLoginForm({...loginForm, password: e.target.value})}
                    />
                  </div>
                </div>
                
                {error && (
                  <div className="p-4 bg-red-50 text-red-600 rounded-2xl flex items-start text-xs font-bold border border-red-100 animate-shake">
                    <ShieldAlert size={18} className="mr-3 shrink-0 mt-0.5" />
                    <p>{error}</p>
                  </div>
                )}

                <button 
                  type="submit" 
                  disabled={loading}
                  className="w-full text-white py-5 rounded-2xl font-black text-lg shadow-2xl transition-all hover:brightness-110 flex items-center justify-center active:scale-95 group" 
                  style={{ backgroundColor: 'var(--primary-color)' }}
                >
                  {loading ? <Loader2 className="animate-spin mr-3" size={24} /> : null}
                  {loading ? 'Hadda waa laguu furayaa...' : 'SOO GAL SYSTEM-KA'}
                  {!loading && <ChevronRight className="ml-2 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" size={20} />}
                </button>

                <div className="flex flex-col items-center space-y-4 pt-4">
                  <div className="flex items-center space-x-2 text-[10px] font-black text-slate-300 uppercase tracking-widest">
                    <div className="w-8 h-px bg-slate-100"></div>
                    <span>Ma haysatid ID?</span>
                    <div className="w-8 h-px bg-slate-100"></div>
                  </div>
                  <button type="button" onClick={() => setView('register')} className="flex items-center space-x-2 text-blue-900 font-black text-xs uppercase tracking-widest hover:underline transition-all">
                    <UserPlus size={16} /> <span>Is Diwaangeli (Register)</span>
                  </button>
                  <div className="flex items-center text-blue-600/60 font-bold text-[10px]">
                    <Phone size={12} className="mr-1.5" /> Support: +252614071123
                  </div>
                </div>
              </form>
            </>
          ) : (
            <RegistrationForm students={state.students} classes={state.classes} onBack={() => setView('login')} onSubmit={handleRegister} />
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 relative">
      <Sidebar 
        role={state.currentUser.role} 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        onLogout={handleLogout}
        schoolName={state.settings.schoolName}
        systemName={state.settings.systemName}
        logoUrl={state.settings.logoUrl}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        pendingCount={state.students.filter(s => s.status === 'pending').length}
        currentUserId={state.currentUser.id}
      />
      <main className="lg:pl-72 transition-all duration-300 min-h-screen">
        <div className="p-4 md:p-8">
          <header className="flex flex-col md:flex-row md:items-center justify-between mb-8 md:mb-10 gap-4">
            <div className="flex items-center space-x-4">
              <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden p-3 bg-white rounded-2xl shadow-sm border border-slate-100 text-blue-900"><Menu size={20} /></button>
              <div>
                <h1 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight capitalize">{activeTab.replace('-', ' ')}</h1>
                <p className="text-slate-500 font-medium text-sm">Ku soo dhowaad, {state.currentUser.name}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 cursor-pointer group" onClick={() => setActiveTab('profile')}>
              <div className="text-right">
                <p className="text-sm font-black text-slate-800 group-hover:text-blue-600 transition-colors">{state.currentUser.name}</p>
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">{state.currentUser.role}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-2xl overflow-hidden flex items-center justify-center font-black border-2 border-white shadow-lg group-hover:scale-110 transition-all text-blue-900">
                {state.currentUser.avatar ? <img src={state.currentUser.avatar} className="w-full h-full object-cover" /> : state.currentUser.name.charAt(0)}
              </div>
            </div>
          </header>

          <div className="animate-in fade-in slide-in-from-bottom-2 duration-700">
            {activeTab === 'dashboard' && (
              state.currentUser.role === UserRole.ADMIN ? <AdminDashboard state={state} /> :
              state.currentUser.role === UserRole.TEACHER ? <TeacherDashboard teacher={state.currentUser as Teacher} state={state} onNavigate={setActiveTab} /> :
              <StudentView student={state.currentUser as Student} attendance={state.attendance} results={state.results} />
            )}
            
            {activeTab === 'profile' && (
              <ProfileView user={state.currentUser} onUpdate={(u) => setState(p => ({...p, currentUser: u}))} />
            )}

            {activeTab === 'registrations' && state.currentUser.role === UserRole.ADMIN && (
              <RegistrationManagement 
                students={state.students} 
                onApprove={(id) => setState(p => ({...p, students: p.students.map(s => s.id === id ? {...s, status: 'approved'} : s)}))} 
                onReject={(id) => setState(p => ({...p, students: p.students.map(s => s.id === id ? {...s, status: 'rejected'} : s)}))} 
              />
            )}

            {activeTab === 'admins' && state.currentUser.role === UserRole.ADMIN && (
              <AdminManagement 
                admins={state.users.filter(u => u.role === UserRole.ADMIN)} 
                onAdd={(u) => setState(p => ({...p, users: [...p.users, u]}))} 
                onUpdate={(u) => setState(p => ({...p, users: p.users.map(o => o.id === u.id ? u : o)}))} 
                onDelete={(id) => setState(p => ({...p, users: p.users.filter(u => u.id !== id)}))} 
              />
            )}

            {activeTab === 'reading' && (
              state.currentUser.role === UserRole.TEACHER ? (
                <LessonManagement 
                  teacher={state.currentUser as Teacher} 
                  lessons={state.lessons} 
                  onAdd={(l) => setState(p => ({...p, lessons: [...p.lessons, l]}))} 
                  onDelete={(id) => setState(p => ({...p, lessons: p.lessons.filter(l => l.id !== id)}))} 
                />
              ) : state.currentUser.role === UserRole.ADMIN ? (
                <LessonMonitor 
                  state={state} 
                  onDelete={(id) => setState(p => ({...p, lessons: p.lessons.filter(l => l.id !== id)}))} 
                />
              ) : (
                <ReadingSchedule 
                  student={state.currentUser as Student} 
                  lessons={state.lessons} 
                  onStartAI={setActiveQuizLesson} 
                />
              )
            )}

            {activeTab === 'ai-teacher' && state.currentUser.role === UserRole.STUDENT && (
              <AITeacher 
                student={state.currentUser as Student} 
                results={state.results} 
                attendance={state.attendance} 
                quizLesson={activeQuizLesson} 
                onQuizSubmit={(r) => setState(p => ({...p, results: [...p.results, r]}))} 
              />
            )}

            {activeTab === 'students' && (state.currentUser.role === UserRole.ADMIN || state.currentUser.role === UserRole.TEACHER) && (
              state.currentUser.role === UserRole.ADMIN 
                ? <StudentManagement students={state.students.filter(s => s.status === 'approved')} classes={state.classes} onAdd={(s) => setState(p => ({...p, students: [...p.students, s]}))} onUpdate={(s) => setState(p => ({...p, students: p.students.map(o => o.id === s.id ? s : o)}))} onDelete={(id) => setState(p => ({...p, students: p.students.filter(s => s.id !== id)}))} />
                : <StudentList students={state.students.filter(s => s.status === 'approved' && (state.currentUser as Teacher).assignedClasses.includes(s.className))} />
            )}

            {activeTab === 'teachers' && state.currentUser.role === UserRole.ADMIN && (
              <TeacherManagement 
                teachers={state.teachers} 
                onAdd={(t) => setState(p => ({...p, teachers: [...p.teachers, t]}))} 
                onUpdate={(t) => setState(p => ({...p, teachers: p.teachers.map(o => o.id === t.id ? t : o)}))} 
                onDelete={(id) => setState(p => ({...p, teachers: p.teachers.filter(t => t.id !== id)}))} 
              />
            )}

            {activeTab === 'classes' && state.currentUser.role === UserRole.ADMIN && (
              <ClassManagement 
                classes={state.classes} 
                teachers={state.teachers} 
                students={state.students} 
                onAdd={(c) => setState(p => ({...p, classes: [...p.classes, c]}))} 
                onUpdate={(c) => setState(p => ({...p, classes: p.classes.map(o => o.id === c.id ? c : o)}))} 
                onDelete={(id) => setState(p => ({...p, classes: p.classes.filter(c => c.id !== id)}))} 
              />
            )}

            {activeTab === 'attendance' && (
              state.currentUser.role === UserRole.TEACHER ? (
                <AttendanceTracker 
                  students={state.students.filter(s => s.className === (state.currentUser as Teacher).assignedClasses[0])} 
                  className={(state.currentUser as Teacher).assignedClasses[0]} 
                  onSave={(recs) => setState(p => ({...p, attendance: [...p.attendance, ...recs]}))} 
                />
              ) : state.currentUser.role === UserRole.ADMIN ? (
                <AttendanceManagement 
                  state={state} 
                  onUpdate={(recs) => setState(p => ({...p, attendance: p.attendance.map(a => recs.find(r => r.id === a.id) || a)}))} 
                  onDelete={(id) => setState(p => ({...p, attendance: p.attendance.filter(a => a.id !== id)}))} 
                />
              ) : (
                <StudentAttendanceView student={state.currentUser as Student} attendance={state.attendance} />
              )
            )}

            {activeTab === 'results' && (
              state.currentUser.role === UserRole.TEACHER ? (
                <ResultEntry 
                  students={state.students.filter(s => s.className === (state.currentUser as Teacher).assignedClasses[0])} 
                  className={(state.currentUser as Teacher).assignedClasses[0]} 
                  teacherSubject={(state.currentUser as Teacher).subject} 
                  onSave={(res) => setState(p => ({...p, results: [...p.results, ...res]}))} 
                />
              ) : state.currentUser.role === UserRole.ADMIN ? (
                <ResultManagement 
                  state={state} 
                  onUpdate={(res) => setState(p => ({...p, results: p.results.map(r => res.find(nr => nr.id === r.id) || r)}))} 
                  onDelete={(id) => setState(p => ({...p, results: p.results.filter(r => r.id !== id)}))} 
                />
              ) : (
                <StudentView student={state.currentUser as Student} attendance={state.attendance} results={state.results} />
              )
            )}

            {activeTab === 'backup' && state.currentUser.role === UserRole.ADMIN && (
              <BackupManagement state={state} />
            )}

            {activeTab === 'settings' && state.currentUser.role === UserRole.ADMIN && (
              <SettingsManagement state={state} onUpdate={(s) => setState(p => ({...p, settings: s}))} />
            )}

            {activeTab === 'album' && state.currentUser.role === UserRole.ADMIN && (
              <StudentAlbum students={state.students} classes={state.classes} />
            )}
          </div>
        </div>
      </main>
      <style>{`
        :root { --primary-color: ${state.settings.primaryColor}; --secondary-color: ${state.settings.secondaryColor}; }
        .sidebar-active { background-color: white !important; color: var(--primary-color) !important; box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1); }
        @keyframes shake { 0%, 100% { transform: translateX(0); } 25% { transform: translateX(-4px); } 75% { transform: translateX(4px); } }
        .animate-shake { animation: shake 0.3s ease-in-out; }
        .custom-scrollbar::-webkit-scrollbar { width: 5px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
      `}</style>
    </div>
  );
};

export default App;
