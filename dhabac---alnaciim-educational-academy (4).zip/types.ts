
export enum UserRole {
  ADMIN = 'ADMIN',
  TEACHER = 'TEACHER',
  STUDENT = 'STUDENT'
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  email?: string;
  password?: string;
  phone?: string;
  avatar?: string;
}

export interface Student extends User {
  idNumber: string; // Used for login
  className: string;
  status?: 'approved' | 'pending' | 'rejected';
}

export interface Teacher extends User {
  subject: string;
  assignedClasses: string[];
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  date: string;
  status: 'Present' | 'Absent' | 'Late';
  className: string;
}

export interface ExamResult {
  id: string;
  studentId: string;
  subject: string;
  title?: string; 
  marks: number;
  maxMarks: number;
  grade: string;
  date: string;
  type: 'Exam' | 'Quiz' | 'Test' | 'AI Evaluation' | 'Assignment';
}

export interface ReadingMaterial {
  id: string;
  teacherId: string;
  className: string;
  title: string;
  description: string;
  pdfUrl: string; // Link to the PDF
  contentSummary: string; // Background for AI
  date: string;
}

// --- Structured Quiz System Types ---

export interface QuizQuestion {
  id: string;
  quizId: string;
  questionText: string;
  options: string[];
  correctOptionIndex: number;
  points: number;
}

export interface Quiz {
  id: string;
  lessonId?: string;
  teacherId: string;
  className: string;
  title: string;
  description: string;
  questions: QuizQuestion[];
  createdAt: string;
}

export interface QuizAttempt {
  id: string;
  quizId: string;
  studentId: string;
  studentName: string;
  answers: number[]; // Indices of selected options
  score: number;
  maxScore: number;
  completedAt: string;
}

export interface SchoolClass {
  id: string;
  name: string;
  students: string[]; // IDs
  teacherId?: string;
}

export interface SchoolSettings {
  schoolName: string;
  systemName: string;
  primaryColor: string;
  secondaryColor: string;
  logoUrl: string;
}

export interface AppState {
  users: User[];
  students: Student[];
  teachers: Teacher[];
  classes: SchoolClass[];
  attendance: AttendanceRecord[];
  results: ExamResult[];
  lessons: ReadingMaterial[];
  quizzes: Quiz[];
  settings: SchoolSettings;
  currentUser: User | null;
}
