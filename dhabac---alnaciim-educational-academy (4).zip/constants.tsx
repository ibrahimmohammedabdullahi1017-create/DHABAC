
import { UserRole, Student, Teacher, SchoolClass, ExamResult, AttendanceRecord } from './types';

export const INITIAL_STUDENTS: Student[] = [
  { id: 's1', idNumber: 'AL-1001', name: 'Ahmed Farah', role: UserRole.STUDENT, className: 'Grade 10-A', password: '123', status: 'approved' },
  { id: 's2', idNumber: 'AL-1002', name: 'Zahra Ali', role: UserRole.STUDENT, className: 'Grade 10-A', password: '123', status: 'approved' },
  { id: 's3', idNumber: 'AL-1003', name: 'Mohamed Hassan', role: UserRole.STUDENT, className: 'Grade 9-B', password: '123', status: 'approved' },
];

export const INITIAL_TEACHERS: Teacher[] = [
  { id: 't1', name: 'Mr. Jama Mohamed', role: UserRole.TEACHER, subject: 'Mathematics', assignedClasses: ['Grade 10-A'], password: '123' },
  { id: 't2', name: 'Ms. Amina Abdi', role: UserRole.TEACHER, subject: 'English', assignedClasses: ['Grade 9-B'], password: '123' },
];

export const INITIAL_CLASSES: SchoolClass[] = [
  { id: 'c1', name: 'Grade 10-A', students: ['s1', 's2'], teacherId: 't1' },
  { id: 'c2', name: 'Grade 9-B', students: ['s3'], teacherId: 't2' },
];

export const MOCK_RESULTS: ExamResult[] = [
  { id: 'r1', studentId: 's1', subject: 'Math', title: 'First Term Exam', marks: 85, maxMarks: 100, grade: 'A', date: '2023-12-01', type: 'Exam' },
  { id: 'r2', studentId: 's1', subject: 'Physics', title: 'Energy Quiz', marks: 78, maxMarks: 100, grade: 'B', date: '2023-12-05', type: 'Quiz' },
  { id: 'r3', studentId: 's2', subject: 'Math', title: 'First Term Exam', marks: 92, maxMarks: 100, grade: 'A+', date: '2023-12-01', type: 'Exam' },
];

export const COLORS = {
  primary: '#1e3a8a', // Dark Blue
  secondary: '#3b82f6', // Bright Blue
  accent: '#eff6ff', // White Blue / Light Blue
  text: '#1f2937',
};
