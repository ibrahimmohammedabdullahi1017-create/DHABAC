
import React, { useState, useMemo } from 'react';
import { SchoolClass, Student } from '../../types';
import { GraduationCap, ArrowLeft, User, Lock, BookOpen, Save, CheckCircle2, Phone, Info, PartyPopper } from 'lucide-react';

interface RegistrationFormProps {
  classes: SchoolClass[];
  students: Student[];
  onSubmit: (data: any) => Promise<string>;
  onBack: () => void;
}

const RegistrationForm: React.FC<RegistrationFormProps> = ({ classes, students, onSubmit, onBack }) => {
  // Logic to find the next sequential ID (e.g., AL-1004)
  const nextIdSuggestion = useMemo(() => {
    const studentIds = students
      .map(s => {
        const match = s.idNumber.match(/(\d+)/);
        return match ? parseInt(match[0]) : 0;
      })
      .filter(id => id > 0);
    
    const maxId = studentIds.length > 0 ? Math.max(...studentIds) : 1000;
    const prefix = students[0]?.idNumber.split('-')[0] || 'AL';
    return `${prefix}-${maxId + 1}`;
  }, [students]);

  const [formData, setFormData] = useState({
    name: '',
    idNumber: '', 
    className: '',
    password: ''
  });
  
  const [submissionStatus, setSubmissionStatus] = useState<'none' | 'pending' | 'approved'>('none');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const status = await onSubmit(formData);
      setSubmissionStatus(status as any);
    } catch (err) {
      // Error is handled by parent App.tsx
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submissionStatus !== 'none') {
    return (
      <div className="p-10 text-center space-y-6 animate-in zoom-in-95 duration-500">
        <div className={`w-24 h-24 rounded-full flex items-center justify-center mx-auto shadow-inner ${submissionStatus === 'approved' ? 'bg-green-100 text-green-600' : 'bg-blue-100 text-blue-600'}`}>
          {submissionStatus === 'approved' ? <PartyPopper size={56} /> : <CheckCircle2 size={56} />}
        </div>
        <div>
          <h2 className="text-2xl font-black text-slate-800 mb-2">
            {submissionStatus === 'approved' ? 'Waa laguu aqbalay!' : 'Codsiga waa la xareeyay!'}
          </h2>
          <p className="text-slate-500 font-medium text-sm leading-relaxed">
            {submissionStatus === 'approved' 
              ? 'Maadaama aad isticmaashay ID-ga xiga, system-ku si toos ah ayuu kuu aqbalay. Hadda waad gali kartaa dashboard-kaaga.' 
              : 'Sug inta maamulku kuu oggolaanayo codsigaaga maadaama ID-gu uusan ahayn midka xiga.'}
          </p>
        </div>
        
        <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100 flex items-center space-x-3 text-left">
          <div className="p-2 bg-white rounded-xl text-blue-600 shadow-sm">
            <Phone size={18} />
          </div>
          <div>
            <p className="text-[10px] font-black text-blue-900 uppercase tracking-widest">Caawinaad Dheeraad ah</p>
            <p className="text-xs font-bold text-blue-700">La xariir +252614071123 si laguu caawiyo.</p>
          </div>
        </div>

        <button 
          onClick={submissionStatus === 'approved' ? () => window.location.reload() : onBack}
          className="w-full bg-blue-900 text-white py-4 rounded-xl font-bold shadow-lg hover:bg-blue-800 transition-all active:scale-95"
        >
          {submissionStatus === 'approved' ? 'GAL DASHBOARD-KA' : 'Ku noqo Bogga Soo Gelidda'}
        </button>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6 animate-in slide-in-from-right-4 duration-300">
      <button onClick={onBack} className="flex items-center text-slate-400 hover:text-blue-900 font-bold text-xs transition-colors mb-4">
        <ArrowLeft size={16} className="mr-2" /> Dib u noqo
      </button>

      <div className="text-center mb-4">
        <h2 className="text-2xl font-black text-blue-900 tracking-tight">Is Diwaangeli (Register)</h2>
        <p className="text-xs text-slate-400 font-bold uppercase mt-1">Fadlan geli xogtaada saxda ah</p>
      </div>

      <div className="bg-amber-50 border border-amber-100 p-4 rounded-2xl flex items-start space-x-3">
        <Info className="text-amber-600 shrink-0 mt-0.5" size={18} />
        <div>
          <p className="text-[10px] font-black text-amber-900 uppercase tracking-widest">Xasuusin Muhiim ah</p>
          <p className="text-xs text-amber-700 font-medium mt-1">
            Si laguu aqbalo <b>si toos ah</b>, fadlan isticmaal ID-ga xiga oo ah: <span className="font-black underline">{nextIdSuggestion}</span>
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Magacaaga oo buuxa</label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
            <input 
              type="text" 
              required
              placeholder="Geli magacaaga"
              className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm"
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
            />
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Role Number / ID Number</label>
          <div className="relative">
            <GraduationCap className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
            <input 
              type="text" 
              required
              placeholder={`Tusaale: ${nextIdSuggestion}`}
              className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm"
              value={formData.idNumber}
              onChange={e => setFormData({...formData, idNumber: e.target.value})}
            />
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Dooro Fasalkaaga</label>
          <div className="relative">
            <BookOpen className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
            <select 
              required
              className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm appearance-none"
              value={formData.className}
              onChange={e => setFormData({...formData, className: e.target.value})}
            >
              <option value="">-- Dooro Fasal --</option>
              {classes.map(cls => <option key={cls.id} value={cls.name}>{cls.name}</option>)}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Password cusub</label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
            <input 
              type="password" 
              required
              placeholder="••••••••"
              className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm"
              value={formData.password}
              onChange={e => setFormData({...formData, password: e.target.value})}
            />
          </div>
        </div>

        <button 
          type="submit"
          disabled={isSubmitting}
          className={`w-full bg-blue-900 text-white py-4 rounded-xl font-bold shadow-lg hover:bg-blue-800 active:scale-95 transition-all flex items-center justify-center space-x-2 ${isSubmitting ? 'opacity-70 cursor-wait' : ''}`}
        >
          {isSubmitting ? (
            <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
          ) : (
            <Save size={18} />
          )}
          <span>{isSubmitting ? 'Codsigii waa la dirayaa...' : 'DIR CODSIGA DIWAANGELINTA'}</span>
        </button>
      </form>
      
      <div className="mt-4 pt-4 border-t border-slate-100">
        <p className="text-[10px] text-center text-slate-400 font-medium">
          Haddii xog ka qaldantay ama aad u baahan tahay Role Number: <br/>
          <span className="text-blue-600 font-bold">+252614071123</span>
        </p>
      </div>
    </div>
  );
};

export default RegistrationForm;
