
import React, { useState, useRef } from 'react';
import { AppState } from '../../types';
import { 
  ShieldCheck, 
  Download, 
  RefreshCw, 
  AlertTriangle, 
  CheckCircle2, 
  Database, 
  Server, 
  History,
  FileJson,
  Users,
  GraduationCap,
  ClipboardCheck
} from 'lucide-react';

interface BackupManagementProps {
  state: AppState;
}

const BackupManagement: React.FC<BackupManagementProps> = ({ state }) => {
  const [showImportWarning, setShowImportWarning] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const importInputRef = useRef<HTMLInputElement>(null);

  const exportData = () => {
    setIsExporting(true);
    setTimeout(() => {
      const dataStr = JSON.stringify(state, null, 2);
      const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
      
      const fileName = `DHABAC_DATA_BACKUP_${new Date().toISOString().split('T')[0]}.json`;
      
      const linkElement = document.createElement('a');
      linkElement.setAttribute('href', dataUri);
      linkElement.setAttribute('download', fileName);
      linkElement.click();
      setIsExporting(false);
    }, 1200);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const importedState = JSON.parse(event.target?.result as string);
        if (importedState.settings && Array.isArray(importedState.students)) {
          localStorage.setItem('DHABAC_DATA', JSON.stringify(importedState));
          window.location.reload();
        } else {
          alert('File-kan ma aha backup sax ah oo system-ka DHABAC ah.');
        }
      } catch (err) {
        alert('Cilad ayaa dhacday markii la aqrinayay file-ka.');
      }
    };
    reader.readAsText(file);
  };

  const stats = [
    { label: 'Students', value: state.students.length, icon: <GraduationCap size={16} /> },
    { label: 'Teachers', value: state.teachers.length, icon: <Users size={16} /> },
    { label: 'Results', value: state.results.length, icon: <FileJson size={16} /> },
    { label: 'Attendance', value: state.attendance.length, icon: <ClipboardCheck size={16} /> },
  ];

  return (
    <div className="max-w-5xl space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Backup Section */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-xl overflow-hidden">
            <div className="p-8 bg-gradient-to-br from-slate-900 to-indigo-950 text-white">
              <div className="flex items-center space-x-4 mb-6">
                <div className="p-4 bg-white/10 backdrop-blur-md rounded-2xl">
                  <ShieldCheck size={32} className="text-blue-400" />
                </div>
                <div>
                  <h3 className="text-2xl font-black tracking-tight">Digital Backup Center</h3>
                  <p className="text-blue-300 text-sm font-medium">Badbaadada xogtaada waa 100/100 laysku halleyn karo.</p>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {stats.map((stat, i) => (
                  <div key={i} className="bg-white/5 border border-white/10 p-4 rounded-2xl">
                    <div className="text-blue-300 mb-1">{stat.icon}</div>
                    <p className="text-xl font-black">{stat.value}</p>
                    <p className="text-[9px] font-bold uppercase tracking-widest opacity-60">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-10 space-y-10">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <div className="p-3 bg-blue-50 text-blue-900 rounded-xl inline-flex mb-2">
                    <Download size={20} />
                  </div>
                  <h4 className="text-lg font-black text-slate-800">Soo degso Kaydka (Export)</h4>
                  <p className="text-xs text-slate-500 font-medium leading-relaxed">
                    Nidaamku wuxuu kuu diyaarinayaa hal file oo dijital ah oo ay ku dhan tahay xogta iskuulka. File-kan ku kaydso Flash ama Cloud.
                  </p>
                  <button 
                    onClick={exportData}
                    disabled={isExporting}
                    className={`w-full py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-lg flex items-center justify-center ${
                      isExporting ? 'bg-slate-100 text-slate-400' : 'bg-blue-900 text-white hover:bg-blue-800'
                    }`}
                  >
                    {isExporting ? <RefreshCw className="animate-spin mr-2" size={16} /> : <Download className="mr-2" size={16} />}
                    {isExporting ? 'Diyaarinaya...' : 'Download School Backup'}
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="p-3 bg-amber-50 text-amber-900 rounded-xl inline-flex mb-2">
                    <RefreshCw size={20} />
                  </div>
                  <h4 className="text-lg font-black text-slate-800">Soo Celi Xogta (Import)</h4>
                  <p className="text-xs text-slate-500 font-medium leading-relaxed">
                    Haddii computer-ku kaa xumaado ama xogtu lunto, isticmaal badhankan si aad dib ugu soo celiso file-kaagii u dambeeyay.
                  </p>
                  <input type="file" ref={importInputRef} onChange={handleImport} className="hidden" accept=".json" />
                  <button 
                    onClick={() => setShowImportWarning(true)}
                    className="w-full bg-white text-amber-900 border-2 border-amber-100 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-amber-50 transition-all shadow-sm flex items-center justify-center"
                  >
                    <Server className="mr-2" size={16} /> Restore from File
                  </button>
                </div>
              </div>

              <div className="pt-8 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center text-green-600 space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-[10px] font-black uppercase tracking-widest">Database is Healthy</span>
                </div>
                <p className="text-[10px] text-slate-400 font-medium italic">Powered by DHABAC Digital Engine v4.0</p>
              </div>
            </div>
          </div>
        </div>

        {/* Status & Sidebar Section */}
        <div className="space-y-6">
          <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
            <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-6 flex items-center">
              <Database size={14} className="mr-2" /> Xaaladda Kaydka
            </h4>
            <div className="space-y-6">
               <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-green-50 text-green-600 rounded-xl flex items-center justify-center shadow-inner">
                    <CheckCircle2 size={20} />
                  </div>
                  <div>
                    <p className="text-xs font-black text-slate-800">Local Integrity</p>
                    <p className="text-[10px] text-slate-400 font-medium">Xogta waa mid sugan</p>
                  </div>
               </div>
               <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center shadow-inner">
                    <Server size={20} />
                  </div>
                  <div>
                    <p className="text-xs font-black text-slate-800">Browser Storage</p>
                    <p className="text-[10px] text-slate-400 font-medium">92% Available</p>
                  </div>
               </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-8 rounded-[2.5rem] text-white shadow-xl">
             <h4 className="text-xs font-black uppercase tracking-widest mb-4 flex items-center opacity-80">
               <History size={14} className="mr-2" /> Talo Muhiim ah
             </h4>
             <p className="text-sm font-medium leading-relaxed italic opacity-90">
               "Kama liidatid inaad maalin kasta markaad iskuulka xirayso aad hal mar 'Download' dhigato xogtaada. Taasi waa 100/100 nabad-galyo."
             </p>
          </div>
        </div>
      </div>

      {showImportWarning && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] p-10 shadow-2xl text-center border border-slate-100 animate-in zoom-in-95">
            <div className="w-20 h-20 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertTriangle size={40} />
            </div>
            <h4 className="text-2xl font-black text-slate-900 mb-4">Ma Hubtaa?</h4>
            <p className="text-slate-500 font-medium mb-8 leading-relaxed">
              Haddii aad xog cusub soo geliso, dhammaan xogta hadda ku jirta system-ka waa la tirtiri doonaa. Hubi inaad haysato backup-ka xogtaada.
            </p>
            <div className="flex flex-col gap-3">
              <button 
                onClick={() => {
                  setShowImportWarning(false);
                  importInputRef.current?.click();
                }}
                className="w-full bg-amber-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-amber-700 transition-all shadow-lg"
              >
                Haa, Soo Gali Xogta
              </button>
              <button 
                onClick={() => setShowImportWarning(false)}
                className="w-full bg-slate-100 text-slate-500 py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-200 transition-all"
              >
                Iska Jooji
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BackupManagement;
