
import React, { useState } from 'react';
import { User, UserRole } from '../../types';
import { Search, UserPlus, Edit2, Trash2, X, Save, ShieldCheck, Key } from 'lucide-react';

interface AdminManagementProps {
  admins: User[];
  onAdd: (admin: User) => void;
  onUpdate: (admin: User) => void;
  onDelete: (id: string) => void;
}

const AdminManagement: React.FC<AdminManagementProps> = ({ admins, onAdd, onUpdate, onDelete }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingAdmin, setEditingAdmin] = useState<User | null>(null);
  
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    password: '',
    email: '',
    phone: ''
  });

  const filteredAdmins = admins.filter(a => 
    a.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingAdmin) {
      onUpdate({ ...editingAdmin, ...formData });
    } else {
      const newAdmin: User = {
        ...formData,
        role: UserRole.ADMIN,
      };
      onAdd(newAdmin);
    }
    closeModal();
  };

  const openEdit = (admin: User) => {
    setEditingAdmin(admin);
    setFormData({
      id: admin.id,
      name: admin.name,
      password: admin.password || '',
      email: admin.email || '',
      phone: admin.phone || ''
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingAdmin(null);
    setFormData({ id: '', name: '', password: '', email: '', phone: '' });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="relative max-w-md w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Raadi Maamule..."
            className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500 text-sm font-bold shadow-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-blue-900 text-white px-6 py-3 rounded-2xl font-black text-sm flex items-center justify-center hover:bg-blue-800 transition-all shadow-lg"
        >
          <UserPlus size={18} className="mr-2" /> Ku dar Manager
        </button>
      </div>

      <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
              <tr>
                <th className="px-8 py-5">Maamulaha (Manager)</th>
                <th className="px-8 py-5">Login ID</th>
                <th className="px-8 py-5">Password</th>
                <th className="px-8 py-5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAdmins.map(admin => (
                <tr key={admin.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-8 py-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-900 font-black">
                        {admin.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-slate-800">{admin.name}</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">System Manager</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className="bg-blue-50 text-blue-700 px-3 py-1 rounded-lg text-xs font-black border border-blue-100">
                      {admin.id}
                    </span>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex items-center space-x-2 text-slate-400">
                      <Key size={14} />
                      <span className="text-xs font-mono">********</span>
                    </div>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <button 
                        onClick={() => openEdit(admin)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-xl transition-colors"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button 
                        onClick={() => {
                          if(window.confirm(`Ma hubtaa inaad tirtirto maamulaha ${admin.name}?`)) {
                            onDelete(admin.id);
                          }
                        }}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-xl transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredAdmins.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-8 py-12 text-center text-slate-400 italic">
                    Ma jiraan maamulayaal dheeraad ah oo la helay.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center space-x-3">
                <ShieldCheck className="text-blue-900" size={24} />
                <h3 className="text-xl font-black text-slate-800">
                  {editingAdmin ? 'Cusbooneysii Manager' : 'Ku dar Manager Cusub'}
                </h3>
              </div>
              <button onClick={closeModal} className="text-slate-400 hover:text-slate-600 p-2"><X size={20} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-8 space-y-5">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Magaca Manager-ka</label>
                <input 
                  type="text" 
                  required
                  placeholder="Geli magaca buuxa"
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-bold"
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Login ID (Username)</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g manager1"
                  disabled={!!editingAdmin}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-bold disabled:opacity-50"
                  value={formData.id}
                  onChange={e => setFormData({...formData, id: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Password (Login)</label>
                <input 
                  type="text" 
                  required
                  placeholder="••••••••"
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-bold"
                  value={formData.password}
                  onChange={e => setFormData({...formData, password: e.target.value})}
                />
              </div>
              <button 
                type="submit"
                className="w-full bg-blue-900 text-white py-4 rounded-2xl font-black shadow-lg hover:bg-blue-800 transition-all flex items-center justify-center mt-4"
              >
                <Save size={18} className="mr-2" /> {editingAdmin ? 'Keydi Isbedelka' : 'Abuur Manager-ka'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminManagement;
