
import React, { useState } from 'react';
import { AttendanceRecord, AppState } from '../../types';
import { Search, Edit2, Check, X, Clock, Trash2, Save } from 'lucide-react';

interface AttendanceManagementProps {
  state: AppState;
  onUpdate: (records: AttendanceRecord[]) => void;
  onDelete: (id: string) => void;
}

const AttendanceManagement: React.FC<AttendanceManagementProps> = ({ state, onUpdate, onDelete }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<'Present' | 'Absent' | 'Late'>('Present');

  const filteredAttendance = state.attendance.filter(a => 
    a.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.className.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.date.includes(searchTerm)
  ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const handleStartEdit = (record: AttendanceRecord) => {
    setEditingId(record.id);
    setEditValue(record.status);
  };

  const handleSaveEdit = (record: AttendanceRecord) => {
    onUpdate([{ ...record, status: editValue }]);
    setEditingId(null);
  };

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden animate-in fade-in duration-500">
      <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h3 className="text-xl font-black text-slate-800">Maamulista Attendence-ka (Admin)</h3>
        <div className="relative max-w-sm w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Raadi magac, fasal ama taariikh..."
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
            <tr>
              <th className="px-6 py-4">Student</th>
              <th className="px-6 py-4">Class</th>
              <th className="px-6 py-4">Date</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {filteredAttendance.length > 0 ? filteredAttendance.map(record => (
              <tr key={record.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4 font-bold text-slate-800">{record.studentName}</td>
                <td className="px-6 py-4 text-slate-500 font-medium">{record.className}</td>
                <td className="px-6 py-4 text-slate-500 font-medium">{record.date}</td>
                <td className="px-6 py-4">
                  {editingId === record.id ? (
                    <select 
                      value={editValue} 
                      onChange={(e) => setEditValue(e.target.value as any)}
                      className="px-2 py-1 border border-blue-200 rounded-lg text-xs font-bold focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Present">Present</option>
                      <option value="Absent">Absent</option>
                      <option value="Late">Late</option>
                    </select>
                  ) : (
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase ${
                      record.status === 'Present' ? 'bg-green-100 text-green-700' :
                      record.status === 'Absent' ? 'bg-red-100 text-red-700' :
                      'bg-amber-100 text-amber-700'
                    }`}>
                      {record.status}
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end space-x-2">
                    {editingId === record.id ? (
                      <button 
                        onClick={() => handleSaveEdit(record)}
                        className="p-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                      >
                        <Save size={14} />
                      </button>
                    ) : (
                      <button 
                        onClick={() => handleStartEdit(record)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Edit Record"
                      >
                        <Edit2 size={14} />
                      </button>
                    )}
                    <button 
                      onClick={() => onDelete(record.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      title="Delete Record"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </td>
              </tr>
            )) : (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-slate-400 font-medium italic">
                  Ma jiraan xog loo diwaangeliyey attendence.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AttendanceManagement;
