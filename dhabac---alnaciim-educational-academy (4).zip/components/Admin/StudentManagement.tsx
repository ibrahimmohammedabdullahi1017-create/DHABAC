
import React, { useState, useRef } from 'react';
import { Student, SchoolClass, UserRole } from '../../types';
import { Search, Plus, UserPlus, Edit2, Trash2, GraduationCap, X, Save, Camera, Loader2, CheckCircle2 } from 'lucide-react';
import { ProfileService } from '../../services/profileService';

interface StudentManagementProps {
  students: Student[];
  classes: SchoolClass[];
  onAdd: (student: Student) => void;
  onUpdate: (student: Student) => void;
  onDelete: (id: string) => void;
}

const StudentManagement: React.FC<StudentManagementProps> = ({ students, classes, onAdd, onUpdate, onDelete }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    idNumber: '',
    className: '',
    password: '123',
    avatar: ''
  });

  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.idNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.className.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const preview = await ProfileService.convertToBase64(file);
      setFormData(prev => ({ ...prev, avatar: preview }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.className) {
      alert('Fadlan dooro fasal.');
      return;
    }

    setIsSaving(true);
    try {
      if (editingStudent) {
        const finalAvatar = await ProfileService.updateProfile(formData.idNumber, formData, selectedFile || undefined);
        onUpdate({ ...editingStudent, ...formData, avatar: finalAvatar });
      } else {
        // Create profile directly in database
        const finalAvatar = await ProfileService.createProfile({
          idNumber: formData.idNumber,
          name: formData.name,
          role: UserRole.STUDENT,
          className: formData.className,
          password: formData.password,
          status: 'approved' // Manually added students are pre-approved
        }, selectedFile || undefined);

        const newStudent: Student = {
          id: `s-${Date.now()}`,
          idNumber: formData.idNumber,
          name: formData.name,
          role: UserRole.STUDENT,
          className: formData.className,
          password: formData.password,
          avatar: finalAvatar,
          status: 'approved'
        };
        onAdd(newStudent);
      }
      closeModal();
    } catch (err: any) {
      alert('Cilad ayaa dhacday: ' + err.message);
    } finally {
      setIsSaving(false);
    }
  };

  const openEdit = (student: Student) => {
    setEditingStudent(student);
    setFormData({
      name: student.name,
      idNumber: student.idNumber,
      className: student.className,
      password: student.password || '123',
      avatar: student.avatar || ''
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingStudent(null);
    setSelectedFile(null);
    setFormData({ name: '', idNumber: '', className: '', password: '123', avatar: '' });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="relative max-w-md w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Raadi Arday, ID ama Fasal..."
            className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500 text-sm font-bold shadow-sm outline-none"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-blue-900 text-white px-6 py-3 rounded-2xl font-black text-sm flex items-center justify-center hover:bg-blue-800 transition-all shadow-lg active:scale-95"
        >
          <UserPlus size={18} className="mr-2" /> Ku dar Arday Cusub
        </button>
      </div>

      <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
              <tr>
                <th className="px-8 py-5">Ardayga (Student)</th>
                <th className="px-8 py-5">Fasalka (Class)</th>
                <th className="px-8 py-5">ID Number</th>
                <th className="px-8 py-5 text-right">Ficil (Actions)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length > 0 ? filteredStudents.map(student => (
                <tr key={student.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-8 py-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-2xl bg-blue-100 overflow-hidden flex items-center justify-center text-blue-900 font-black border-2 border-white shadow-sm">
                        {student.avatar ? (
                          <img src={student.avatar} className="w-full h-full object-cover" />
                        ) : (
                          student.name.charAt(0)
                        )}
                      </div>
                      <div>
                        <p className="font-bold text-slate-800 text-base">{student.name}</p>
                        <p className="text-[10px] text-slate-400 font-black uppercase tracking-tighter">Student Account</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className="bg-indigo-50 text-indigo-700 px-3 py-1.5 rounded-xl text-[10px] font-black border border-indigo-100 uppercase tracking-widest">
                      {student.className}
                    </span>
                  </td>
                  <td className="px-8 py-6">
                    <p className="text-xs font-black text-slate-600 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200 inline-block">
                      {student.idNumber}
                    </p>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <button 
                        onClick={() => openEdit(student)}
                        className="p-2.5 text-blue-600 hover:bg-blue-50 rounded-xl transition-all active:scale-90"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button 
                        onClick={() => {
                          if(window.confirm(`Ma hubtaa inaad tirtirto ardayga ${student.name}?`)) onDelete(student.id);
                        }}
                        className="p-2.5 text-red-600 hover:bg-red-50 rounded-xl transition-all active:scale-90"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={4} className="px-8 py-20 text-center">
                    <p className="text-slate-400 font-bold uppercase text-xs tracking-widest">Ma jiro arday la helay.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 border border-slate-100">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center space-x-3">
                <GraduationCap className="text-blue-900" size={24} />
                <h3 className="text-xl font-black text-slate-800">
                  {editingStudent ? 'Cusbooneysii Arday' : 'Diiwaangeli Arday'}
                </h3>
              </div>
              <button onClick={closeModal} className="text-slate-400 hover:text-slate-600 p-2 bg-white rounded-xl border border-slate-200 transition-all"><X size={20} /></button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-8 space-y-5">
              <div className="flex justify-center mb-6">
                <div className="relative group">
                  <div className="w-28 h-28 rounded-3xl bg-slate-100 overflow-hidden border-4 border-white shadow-xl relative">
                    {formData.avatar ? (
                      <img src={formData.avatar} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-slate-300">
                        <Camera size={32} />
                        <span className="text-[8px] font-black uppercase tracking-widest mt-1">Sawirka</span>
                      </div>
                    )}
                  </div>
                  <button 
                    type="button" 
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white rounded-3xl"
                  >
                    <Plus size={24} />
                  </button>
                  <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
                </div>
              </div>
              
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Magaca Ardayga (Full Name)</label>
                  <input 
                    type="text" required
                    placeholder="Geli magaca buuxa"
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none font-bold text-slate-800 transition-all"
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">ID Number (Login)</label>
                    <input 
                      type="text" required
                      disabled={!!editingStudent}
                      placeholder="e.g AL-1004"
                      className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none font-bold text-slate-800 transition-all disabled:opacity-50"
                      value={formData.idNumber}
                      onChange={e => setFormData({...formData, idNumber: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Fasalka (Class)</label>
                    <select 
                      required
                      className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none font-bold text-slate-800 transition-all appearance-none cursor-pointer"
                      value={formData.className}
                      onChange={e => setFormData({...formData, className: e.target.value})}
                    >
                      <option value="">-- Dooro --</option>
                      {classes.map(cls => (
                        <option key={cls.id} value={cls.name}>{cls.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Password-ka Gelitaanka</label>
                  <input 
                    type="text" required
                    placeholder="••••••••"
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none font-bold text-slate-800 transition-all"
                    value={formData.password}
                    onChange={e => setFormData({...formData, password: e.target.value})}
                  />
                </div>
              </div>

              <div className="pt-4">
                <button 
                  type="submit"
                  disabled={isSaving}
                  className={`w-full py-4 rounded-2xl font-black shadow-xl transition-all flex items-center justify-center space-x-2 ${
                    isSaving ? 'bg-blue-800/80 text-white/50 cursor-wait' : 'bg-blue-900 text-white hover:bg-blue-800 active:scale-95'
                  }`}
                >
                  {isSaving ? <Loader2 className="animate-spin" size={20} /> : <CheckCircle2 size={20} />}
                  <span>{isSaving ? 'Kaydinaya Cloud-ka...' : (editingStudent ? 'Cusbooneysii Ardayga' : 'Diiwaangeli Ardayga')}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentManagement;
