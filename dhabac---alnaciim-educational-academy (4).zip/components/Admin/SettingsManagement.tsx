
import React, { useState, useEffect, useRef } from 'react';
import { AppState, SchoolSettings } from '../../types';
import { 
  Settings, 
  ImageIcon, 
  Palette, 
  Globe, 
  ShieldCheck, 
  Save, 
  CheckCircle2, 
  X, 
  FileUp, 
  Download, 
  RefreshCw,
  AlertTriangle
} from 'lucide-react';

interface SettingsManagementProps {
  state: AppState;
  onUpdate: (settings: SchoolSettings) => void;
}

const SettingsManagement: React.FC<SettingsManagementProps> = ({ state, onUpdate }) => {
  const [formData, setFormData] = useState<SchoolSettings>({
    schoolName: state.settings.schoolName,
    systemName: state.settings.systemName,
    primaryColor: state.settings.primaryColor,
    secondaryColor: state.settings.secondaryColor || '#3b82f6',
    logoUrl: state.settings.logoUrl || ''
  });
  
  const [saved, setSaved] = useState(false);
  const [showImportWarning, setShowImportWarning] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const importInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setFormData({
      schoolName: state.settings.schoolName,
      systemName: state.settings.systemName,
      primaryColor: state.settings.primaryColor,
      secondaryColor: state.settings.secondaryColor || '#3b82f6',
      logoUrl: state.settings.logoUrl || ''
    });
  }, [state.settings]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        alert('Fadlan soo xulo sawir kaliya (Image files).');
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, logoUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const removeLogo = () => {
    setFormData(prev => ({ ...prev, logoUrl: '' }));
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdate(formData);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  // --- Backup Functions ---
  const exportData = () => {
    const dataStr = JSON.stringify(state, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `DHABAC_BACKUP_${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const importedState = JSON.parse(event.target?.result as string);
        // Basic validation: check if it looks like an AppState
        if (importedState.settings && Array.isArray(importedState.students)) {
          localStorage.setItem('DHABAC_DATA', JSON.stringify(importedState));
          window.location.reload(); // Reload to apply the imported data
        } else {
          alert('File-kan ma aha backup sax ah oo system-ka DHABAC ah.');
        }
      } catch (err) {
        alert('Cilad ayaa dhacday markii la aqrinayay file-ka.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="max-w-5xl space-y-8 animate-in fade-in duration-500 pb-10">
      <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-8 bg-slate-50/50 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-4 text-white rounded-2xl shadow-xl transform rotate-2" style={{ backgroundColor: 'var(--primary-color)' }}>
              <Settings size={28} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-slate-800 tracking-tight">System Settings</h3>
              <p className="text-sm text-slate-500 font-medium">Maamul magaca, midabada iyo badbaadada xogta.</p>
            </div>
          </div>
          {saved && (
            <div className="flex items-center text-green-600 font-black text-sm animate-bounce">
              <CheckCircle2 size={24} className="mr-2" /> Waa la kaydiyay!
            </div>
          )}
        </div>

        <form onSubmit={handleSave} className="p-10 space-y-10">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Logo Upload Section */}
            <div className="space-y-6">
              <h4 className="text-xs font-black uppercase tracking-widest border-b pb-2 flex items-center" style={{ color: 'var(--primary-color)', borderColor: 'rgba(var(--primary-color), 0.1)' }}>
                <ImageIcon size={14} className="mr-2" /> Logo-ga Iskuulka
              </h4>
              <div className="relative group">
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  className="hidden" 
                  accept="image/*"
                />
                
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className={`aspect-square rounded-[2rem] border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-all relative overflow-hidden ${
                    formData.logoUrl ? 'border-blue-500 bg-white' : 'border-slate-200 bg-slate-50 hover:border-blue-400 hover:bg-blue-50/50'
                  }`}
                >
                  {formData.logoUrl ? (
                    <>
                      <img src={formData.logoUrl} alt="School Logo" className="w-full h-full object-contain p-6" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <p className="text-white text-xs font-black uppercase tracking-widest">Baddal Logo-ga</p>
                      </div>
                      <button 
                        type="button"
                        onClick={(e) => { e.stopPropagation(); removeLogo(); }}
                        className="absolute top-4 right-4 p-2 bg-red-500 text-white rounded-xl shadow-lg hover:bg-red-600 transition-colors"
                      >
                        <X size={16} />
                      </button>
                    </>
                  ) : (
                    <div className="text-center p-6">
                      <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mx-auto mb-4 text-slate-300">
                        <FileUp size={32} />
                      </div>
                      <p className="font-bold text-slate-700 text-sm">Upload Logo</p>
                      <p className="text-[10px] text-slate-400 font-medium mt-1">Guji si aad sawirka iskuulka u soo geliso</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Branding Details */}
            <div className="lg:col-span-2 space-y-8">
              <div className="space-y-6">
                <h4 className="text-xs font-black uppercase tracking-widest border-b pb-2 flex items-center" style={{ color: 'var(--primary-color)', borderColor: 'rgba(var(--primary-color), 0.1)' }}>
                  <Globe size={14} className="mr-2" /> Branding Details
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2.5 ml-1">Magaca Iskuulka</label>
                    <input 
                      type="text" 
                      className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none font-bold text-slate-800 transition-all"
                      value={formData.schoolName}
                      onChange={e => setFormData({...formData, schoolName: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2.5 ml-1">Magaca System-ka</label>
                    <input 
                      type="text" 
                      className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none font-bold text-slate-800 transition-all"
                      value={formData.systemName}
                      onChange={e => setFormData({...formData, systemName: e.target.value})}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <h4 className="text-xs font-black uppercase tracking-widest border-b pb-2 flex items-center" style={{ color: 'var(--primary-color)', borderColor: 'rgba(var(--primary-color), 0.1)' }}>
                  <Palette size={14} className="mr-2" /> Theme Colors
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="p-6 bg-slate-50 rounded-3xl border border-slate-200 group">
                    <div className="flex items-center justify-between mb-4">
                      <p className="text-xs font-black text-slate-600 uppercase tracking-widest">Midabka Koowaad</p>
                      <div className="w-12 h-12 rounded-xl shadow-lg border-2 border-white" style={{ backgroundColor: formData.primaryColor }}></div>
                    </div>
                    <input 
                      type="color" 
                      className="w-full h-12 border-0 p-0 bg-transparent cursor-pointer rounded-xl overflow-hidden"
                      value={formData.primaryColor}
                      onChange={e => setFormData({...formData, primaryColor: e.target.value})}
                    />
                  </div>

                  <div className="p-6 bg-slate-50 rounded-3xl border border-slate-200 group">
                    <div className="flex items-center justify-between mb-4">
                      <p className="text-xs font-black text-slate-600 uppercase tracking-widest">Midabka Labaad</p>
                      <div className="w-12 h-12 rounded-xl shadow-lg border-2 border-white" style={{ backgroundColor: formData.secondaryColor }}></div>
                    </div>
                    <input 
                      type="color" 
                      className="w-full h-12 border-0 p-0 bg-transparent cursor-pointer rounded-xl overflow-hidden"
                      value={formData.secondaryColor}
                      onChange={e => setFormData({...formData, secondaryColor: e.target.value})}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Backup & Reliability Section */}
          <div className="pt-10 border-t border-slate-100">
            <h4 className="text-xs font-black uppercase tracking-widest mb-6 flex items-center text-slate-800">
              <ShieldCheck size={16} className="mr-2 text-blue-600" /> Security & 100/100 Reliability
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div className="p-8 bg-blue-50/40 rounded-[2rem] border border-blue-100/50 flex flex-col justify-between">
                  <div>
                    <h5 className="font-black text-blue-900 mb-2 flex items-center">
                      <Download size={18} className="mr-2" /> Export Backup
                    </h5>
                    <p className="text-xs text-blue-700/70 font-medium leading-relaxed mb-6">
                      Soo degso dhammaan xogta iskuulka (ardayda, macallimiinta, dhibcaha). File-kan ku kaydso meel ammaan ah si aad xogtaada u haysato 100%.
                    </p>
                  </div>
                  <button 
                    type="button"
                    onClick={exportData}
                    className="w-full bg-blue-900 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-800 transition-all flex items-center justify-center shadow-lg shadow-blue-900/10"
                  >
                    Download School Backup
                  </button>
               </div>

               <div className="p-8 bg-amber-50/40 rounded-[2rem] border border-amber-100/50 flex flex-col justify-between">
                  <div>
                    <h5 className="font-black text-amber-900 mb-2 flex items-center">
                      <RefreshCw size={18} className="mr-2" /> Restore System
                    </h5>
                    <p className="text-xs text-amber-700/70 font-medium leading-relaxed mb-6">
                      Haddii xogtaadu ay lunto, halkan ka soo gali file-kaagii backup-ka ahaa si aad nidaamka dib ugu soo celiso sidii uu ahaa.
                    </p>
                  </div>
                  <input 
                    type="file" 
                    ref={importInputRef}
                    onChange={handleImport}
                    className="hidden" 
                    accept=".json"
                  />
                  <button 
                    type="button"
                    onClick={() => setShowImportWarning(true)}
                    className="w-full bg-white text-amber-900 border-2 border-amber-200 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-amber-50 transition-all flex items-center justify-center shadow-sm"
                  >
                    Import / Restore Data
                  </button>
               </div>
            </div>
          </div>

          <div className="flex justify-end pt-6">
            <button 
              type="submit"
              className="w-full md:w-auto text-white px-20 py-5 rounded-[2rem] font-black text-lg shadow-2xl transform hover:-translate-y-1 active:translate-y-0.5 transition-all flex items-center justify-center hover:brightness-110"
              style={{ backgroundColor: 'var(--primary-color)' }}
            >
              <Save size={24} className="mr-3" /> SAVE ALL CHANGES
            </button>
          </div>
        </form>
      </div>

      {/* Import Confirmation Modal */}
      {showImportWarning && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] p-10 shadow-2xl text-center border border-slate-100 animate-in zoom-in-95">
            <div className="w-20 h-20 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertTriangle size={40} />
            </div>
            <h4 className="text-2xl font-black text-slate-900 mb-4">Ma Hubtaa?</h4>
            <p className="text-slate-500 font-medium mb-8 leading-relaxed">
              Haddii aad xog cusub soo geliso, dhammaan xogta hadda ku jirta system-ka waa la tirtiri doonaa. Hubi inaad haysato backup-ka xogtaada.
            </p>
            <div className="flex flex-col gap-3">
              <button 
                onClick={() => {
                  setShowImportWarning(false);
                  importInputRef.current?.click();
                }}
                className="w-full bg-amber-600 text-white py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-amber-700 transition-all"
              >
                Haa, Soo Gali Xogta
              </button>
              <button 
                onClick={() => setShowImportWarning(false)}
                className="w-full bg-slate-100 text-slate-500 py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-200 transition-all"
              >
                Iska Jooji
              </button>
            </div>
          </div>
        </div>
      )}

      <p className="text-center text-[10px] text-slate-300 font-black uppercase tracking-[0.2em]">DHABAC Data Management Protocol v4.0</p>
    </div>
  );
};

export default SettingsManagement;
