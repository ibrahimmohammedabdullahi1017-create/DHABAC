
import React, { useState } from 'react';
import { Student, SchoolClass } from '../../types';
import { Image as ImageIcon, Search, Filter, User, GraduationCap, ChevronRight } from 'lucide-react';

interface StudentAlbumProps {
  students: Student[];
  classes: SchoolClass[];
}

const StudentAlbum: React.FC<StudentAlbumProps> = ({ students, classes }) => {
  const [selectedClass, setSelectedClass] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredStudents = students.filter(s => {
    const matchesClass = selectedClass === 'All' || s.className === selectedClass;
    const matchesSearch = s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          s.idNumber.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesClass && matchesSearch && s.status === 'approved';
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Filters Header */}
      <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-blue-900 text-white rounded-2xl shadow-lg">
            <ImageIcon size={24} />
          </div>
          <div>
            <h3 className="text-xl font-black text-slate-900 tracking-tight">Student Album</h3>
            <p className="text-sm text-slate-500 font-medium">Album-ka sawirada iyo xogta ardayda fasal kasta.</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-4 flex-1 max-w-2xl">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Raadi magaca ama NO..."
              className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex items-center space-x-2 w-full sm:w-auto overflow-x-auto pb-2 sm:pb-0 no-scrollbar">
            <button 
              onClick={() => setSelectedClass('All')}
              className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                selectedClass === 'All' ? 'bg-blue-900 text-white shadow-lg' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
              }`}
            >
              All
            </button>
            {classes.map(cls => (
              <button 
                key={cls.id}
                onClick={() => setSelectedClass(cls.name)}
                className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                  selectedClass === cls.name ? 'bg-blue-900 text-white shadow-lg' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                }`}
              >
                {cls.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Album Grid */}
      {filteredStudents.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
          {filteredStudents.map(student => (
            <div 
              key={student.id} 
              className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden group hover:shadow-xl hover:-translate-y-2 transition-all duration-300"
            >
              {/* Photo Area */}
              <div className="aspect-[4/5] bg-slate-100 relative overflow-hidden flex items-center justify-center text-slate-300">
                {student.avatar ? (
                  <img src={student.avatar} alt={student.name} className="w-full h-full object-cover" />
                ) : (
                  <div className="flex flex-col items-center">
                    <User size={64} strokeWidth={1} />
                    <span className="text-[10px] font-black uppercase mt-2 tracking-widest opacity-40">No Photo</span>
                  </div>
                )}
                {/* ID/NO Badge overlay */}
                <div className="absolute top-3 right-3 bg-blue-900 text-white px-2 py-1 rounded-lg text-[10px] font-black shadow-lg">
                  NO: {student.idNumber}
                </div>
              </div>

              {/* Info Area */}
              <div className="p-4 text-center">
                <h4 className="font-black text-slate-800 text-sm truncate px-1" title={student.name}>
                  {student.name}
                </h4>
                <p className="text-[10px] text-blue-600 font-black uppercase tracking-tighter mt-1">
                  {student.className}
                </p>
                <div className="mt-3 pt-3 border-t border-slate-50 flex items-center justify-center">
                   <span className="text-[9px] font-medium text-slate-400 uppercase tracking-widest">Alnaciim Student</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white p-20 rounded-3xl border border-slate-100 shadow-sm text-center">
          <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center text-slate-200 mx-auto mb-4 border border-slate-100">
            <GraduationCap size={48} />
          </div>
          <h3 className="text-xl font-bold text-slate-800">Ma jiraan arday la helay</h3>
          <p className="text-slate-400 text-sm mt-1">Fadlan hubi raadintaada ama fasalka aad dooratay.</p>
        </div>
      )}

      {/* Footer Info */}
      <div className="flex items-center justify-between px-2">
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
          Showing {filteredStudents.length} of {students.filter(s => s.status === 'approved').length} Students
        </p>
        <p className="text-[10px] text-slate-300 italic">DHABAC Digital Album System</p>
      </div>
    </div>
  );
};

export default StudentAlbum;
