
import React, { useState } from 'react';
import { ReadingMaterial, Teacher, AppState } from '../../types';
import { Search, FileText, Eye, Trash2, Calendar, User, BookOpen, ExternalLink, Filter } from 'lucide-react';

interface LessonMonitorProps {
  state: AppState;
  onDelete: (id: string) => void;
}

const LessonMonitor: React.FC<LessonMonitorProps> = ({ state, onDelete }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLessons = state.lessons.filter(lesson => {
    const teacher = state.teachers.find(t => t.id === lesson.teacherId);
    return (
      lesson.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lesson.className.toLowerCase().includes(searchTerm.toLowerCase()) ||
      teacher?.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="flex items-center space-x-4">
          <div className="p-4 bg-blue-900 text-white rounded-2xl shadow-xl transform rotate-2">
            <BookOpen size={28} />
          </div>
          <div>
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">Kormeerka Casharada</h3>
            <p className="text-sm text-slate-500 font-medium">Halkan ka hubi dhammaan xogta ay macallimiintu u diraan ardayda.</p>
          </div>
        </div>

        <div className="relative max-w-md w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Raadi cashar, macallin ama fasal..."
            className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none font-bold text-sm transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredLessons.length > 0 ? filteredLessons.map(lesson => {
          const teacher = state.teachers.find(t => t.id === lesson.teacherId);
          return (
            <div key={lesson.id} className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all group overflow-hidden relative">
              <div className="absolute top-0 right-0 w-24 h-24 bg-blue-50/50 rounded-full -mr-10 -mt-10 pointer-events-none group-hover:scale-150 transition-transform duration-700"></div>
              
              <div className="flex justify-between items-start mb-6 relative z-10">
                <div className="p-3 bg-blue-100 text-blue-900 rounded-2xl group-hover:bg-blue-900 group-hover:text-white transition-colors duration-300">
                  <FileText size={24} />
                </div>
                <button 
                  onClick={() => {
                    if(window.confirm('Ma hubtaa inaad tirtirto casharkan uu macallinku soo geliyey?')) onDelete(lesson.id);
                  }} 
                  className="p-2.5 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                  title="Tirtir Casharka"
                >
                  <Trash2 size={18} />
                </button>
              </div>

              <div className="relative z-10">
                <h4 className="text-xl font-black text-slate-800 mb-2 truncate" title={lesson.title}>{lesson.title}</h4>
                <div className="flex flex-wrap gap-2 mb-6">
                  <span className="bg-blue-50 text-blue-700 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border border-blue-100">
                    {lesson.className}
                  </span>
                  <span className="bg-slate-50 text-slate-500 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border border-slate-100">
                    {lesson.date}
                  </span>
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 font-bold text-xs">
                      {teacher?.name.charAt(0)}
                    </div>
                    <div>
                      <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">Macallinka</p>
                      <p className="text-sm font-bold text-slate-700">{teacher?.name || 'Unknown'}</p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <a 
                    href={lesson.pdfUrl} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="flex-1 bg-slate-900 text-white py-3 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center hover:bg-blue-900 transition-colors shadow-lg shadow-slate-900/10"
                  >
                    <Eye size={14} className="mr-2" /> Akhri PDF
                  </a>
                </div>
              </div>
            </div>
          );
        }) : (
          <div className="col-span-full py-24 bg-white rounded-[2.5rem] border-2 border-dashed border-slate-100 text-center flex flex-col items-center">
            <div className="w-24 h-24 bg-slate-50 rounded-[2rem] flex items-center justify-center text-slate-200 mb-6">
              <BookOpen size={56} />
            </div>
            <h4 className="text-2xl font-black text-slate-800 tracking-tight">Xog lama helin</h4>
            <p className="text-slate-400 font-medium max-w-xs mx-auto mt-2">
              Wali wax cashar ah oo ay macallimiintu soo geliyeen ma jiraan ama raadintaadu ma lahan natiijo.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default LessonMonitor;
