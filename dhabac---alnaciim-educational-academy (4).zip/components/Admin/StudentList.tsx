
import React, { useState, useMemo } from 'react';
import { Student } from '../../types';
import { 
  Search, 
  Users,
  GraduationCap, 
  Mail, 
  BookOpen, 
  ArrowUp, 
  ArrowDown, 
  ArrowUpDown,
  Filter,
  MoreVertical,
  X,
  ShieldCheck,
  Hash,
  SortAsc,
  SortDesc
} from 'lucide-react';

interface StudentListProps {
  students: Student[];
}

type SortField = 'name' | 'className' | 'idNumber';
type SortOrder = 'asc' | 'desc';

const StudentList: React.FC<StudentListProps> = ({ students }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const filteredAndSortedStudents = useMemo(() => {
    return students
      .filter(s => 
        s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.idNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.className.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .sort((a, b) => {
        const valA = (a[sortField] || '').toString();
        const valB = (b[sortField] || '').toString();
        
        // Natural sort: handles "Grade 9" before "Grade 10" correctly
        const comparison = valA.localeCompare(valB, undefined, { 
          numeric: true, 
          sensitivity: 'base' 
        });
        
        return sortOrder === 'asc' ? comparison : -comparison;
      });
  }, [students, searchTerm, sortField, sortOrder]);

  const SortIndicator = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ArrowUpDown size={14} className="ml-2 opacity-20 group-hover:opacity-50 transition-opacity" />;
    return sortOrder === 'asc' 
      ? <ArrowUp size={14} className="ml-2 text-blue-600 animate-bounce-short" /> 
      : <ArrowDown size={14} className="ml-2 text-blue-600 animate-bounce-short" />;
  };

  const HeaderCell = ({ field, label, icon: Icon }: { field: SortField, label: string, icon: any }) => (
    <th 
      className={`px-8 py-5 cursor-pointer transition-all group sticky top-0 bg-slate-50/95 backdrop-blur-md z-10 select-none border-b border-slate-100 ${
        sortField === field ? 'text-blue-900 bg-blue-50/50' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100/50'
      }`}
      onClick={() => handleSort(field)}
      title={`Sort by ${label} ${sortField === field && sortOrder === 'asc' ? 'Descending' : 'Ascending'}`}
    >
      <div className="flex items-center">
        <Icon size={14} className={`mr-2 ${sortField === field ? 'text-blue-500' : 'text-slate-300'}`} />
        <span className={`text-[11px] font-black uppercase tracking-widest ${sortField === field ? 'underline decoration-blue-500/30 underline-offset-4' : ''}`}>
          {label}
        </span>
        <SortIndicator field={field} />
      </div>
    </th>
  );

  const resetFilters = () => {
    setSortField('name');
    setSortOrder('asc');
    setSearchTerm('');
  };

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Search and Global Actions */}
      <div className="p-8 bg-slate-50/50 border-b border-slate-100 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="flex items-center space-x-4">
          <div className="p-4 bg-blue-900 text-white rounded-2xl shadow-xl transform -rotate-1 group hover:rotate-0 transition-transform cursor-default">
            <GraduationCap size={28} />
          </div>
          <div>
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">Liiska Ardayda</h3>
            <p className="text-sm text-slate-500 font-medium">Habee xogta ardayda adoo isticmaalaya filters-ka.</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-4 flex-1 max-w-2xl">
          <div className="relative flex-1 w-full group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-blue-500 transition-colors" size={18} />
            <input 
              type="text" 
              placeholder="Raadi Magaca, ID Number ama Fasalka..."
              className="w-full pl-12 pr-12 py-3.5 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 text-sm font-bold shadow-sm transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-red-500 transition-colors"
              >
                <X size={16} />
              </button>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            <button 
              onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
              className="p-3 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-blue-600 transition-all shadow-sm"
              title="Toggle Sort Direction"
            >
              {sortOrder === 'asc' ? <SortAsc size={20} /> : <SortDesc size={20} />}
            </button>
            <button 
              onClick={resetFilters}
              className="px-5 py-3 bg-white border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-blue-900 hover:border-blue-200 transition-all shadow-sm whitespace-nowrap"
            >
              Reset All
            </button>
          </div>
        </div>
      </div>

      {/* Sorting Visual Header (Mobile Specific) */}
      <div className="lg:hidden px-8 py-4 bg-blue-50/30 border-b border-slate-100 flex items-center justify-between">
        <div className="flex items-center text-[10px] font-black uppercase text-slate-500 tracking-widest">
          <Filter size={12} className="mr-2" /> Sorting by: 
          <select 
            value={sortField}
            onChange={(e) => setSortField(e.target.value as SortField)}
            className="ml-2 bg-transparent text-blue-900 focus:outline-none font-black"
          >
            <option value="name">Magaca (Name)</option>
            <option value="className">Fasalka (Class)</option>
            <option value="idNumber">ID Number</option>
          </select>
        </div>
        <div className="flex items-center space-x-1">
          <span className="text-[10px] font-black text-blue-600 uppercase">{sortOrder}</span>
        </div>
      </div>

      <div className="overflow-x-auto custom-scrollbar">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr>
              <HeaderCell field="name" label="Ardayga / Student" icon={Users} />
              <HeaderCell field="className" label="Fasalka / Class" icon={BookOpen} />
              <HeaderCell field="idNumber" label="ID Number" icon={Hash} />
              <th className="px-8 py-5 bg-slate-50/95 backdrop-blur-md sticky top-0 z-10 border-b border-slate-100">
                <span className="text-[11px] font-black text-slate-400 uppercase tracking-widest">Status</span>
              </th>
              <th className="px-8 py-5 bg-slate-50/95 backdrop-blur-md sticky top-0 z-10 border-b border-slate-100 text-right">
                <MoreVertical size={16} className="text-slate-300 inline-block" />
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredAndSortedStudents.length > 0 ? filteredAndSortedStudents.map((student, idx) => (
              <tr 
                key={student.id} 
                className="group hover:bg-blue-50/30 transition-all duration-300 animate-in fade-in slide-in-from-left-2"
                style={{ animationDelay: `${idx * 40}ms` }}
              >
                <td className="px-8 py-6">
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-blue-900 font-black border-2 border-white shadow-sm group-hover:shadow-md group-hover:scale-105 transition-all duration-300 ${
                      sortField === 'name' ? 'bg-blue-200 ring-2 ring-blue-500/20' : 'bg-blue-100'
                    }`}>
                      {student.name.charAt(0)}
                    </div>
                    <div>
                      <p className={`font-bold text-base transition-colors ${sortField === 'name' ? 'text-blue-900' : 'text-slate-800'}`}>
                        {student.name}
                      </p>
                      <span className="flex items-center text-[10px] text-slate-400 font-bold uppercase tracking-tighter mt-1">
                        <Mail size={10} className="mr-1.5" /> Alnaciim Student
                      </span>
                    </div>
                  </div>
                </td>
                <td className="px-8 py-6">
                   <div className={`flex items-center space-x-2 transition-all duration-500 ${sortField === 'className' ? 'translate-x-1' : ''}`}>
                      <BookOpen size={14} className={`${sortField === 'className' ? 'text-blue-600' : 'text-slate-300'}`} />
                      <span className={`text-sm font-black tracking-tight ${sortField === 'className' ? 'text-blue-900' : 'text-slate-700'}`}>
                        {student.className}
                      </span>
                   </div>
                </td>
                <td className="px-8 py-6">
                  <span className={`px-4 py-2 rounded-xl text-[11px] font-black uppercase tracking-wider border transition-all duration-300 inline-block ${
                    sortField === 'idNumber' 
                      ? 'bg-blue-900 text-white border-blue-900 shadow-lg shadow-blue-900/20 scale-105' 
                      : 'bg-slate-100 text-slate-600 border-slate-200'
                  }`}>
                    {student.idNumber}
                  </span>
                </td>
                <td className="px-8 py-6">
                   <span className="inline-flex items-center px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest bg-green-50 text-green-700 border border-green-100 shadow-sm">
                     <div className="w-1.5 h-1.5 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                     Active
                   </span>
                </td>
                <td className="px-8 py-6 text-right">
                   <button className="p-2 text-slate-300 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all opacity-0 group-hover:opacity-100">
                     <MoreVertical size={16} />
                   </button>
                </td>
              </tr>
            )) : (
              <tr>
                <td colSpan={5} className="px-8 py-24 text-center">
                  <div className="flex flex-col items-center animate-in zoom-in duration-500">
                    <div className="w-20 h-20 bg-slate-50 rounded-[2.5rem] flex items-center justify-center text-slate-200 mb-6 border-2 border-dashed border-slate-200 rotate-12">
                      <Search size={40} />
                    </div>
                    <h4 className="text-xl font-black text-slate-800 tracking-tight">Eber! Ma jiro arday la helay</h4>
                    <p className="text-slate-400 font-medium mt-2 max-w-xs mx-auto">
                      Ma jiro arday waafaqsan raadintaada ama xulashadaada hadda.
                    </p>
                    <button 
                      onClick={resetFilters}
                      className="mt-6 text-blue-600 font-black text-xs uppercase tracking-widest hover:underline"
                    >
                      Clear all filters
                    </button>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      {/* Footer Meta */}
      <div className="p-8 bg-slate-50/80 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
         <div className="flex items-center space-x-6">
           <p className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center">
             <Users size={14} className="mr-2" /> 
             Total Results: <span className="text-blue-900 ml-1.5">{filteredAndSortedStudents.length} Students</span>
           </p>
           {searchTerm && (
             <div className="flex items-center space-x-2">
               <span className="text-[10px] font-bold text-blue-500 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-100 flex items-center">
                 <Filter size={10} className="mr-1" /> Active Search
               </span>
             </div>
           )}
         </div>
         <div className="flex items-center space-x-2 text-[10px] font-black text-slate-300 uppercase tracking-tighter italic">
           <ShieldCheck size={12} className="text-blue-400" />
           <span>DHABAC Core Sorting Layer v2.0</span>
         </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes bounce-short {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-2px); }
        }
        .animate-bounce-short {
          animation: bounce-short 1s ease-in-out infinite;
        }
      `}} />
    </div>
  );
};

export default StudentList;
