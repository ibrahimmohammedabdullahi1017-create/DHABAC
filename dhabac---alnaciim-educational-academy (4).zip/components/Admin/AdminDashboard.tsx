
import React, { useEffect, useState } from 'react';
import { AppState } from '../../types';
import { StatCard } from '../Shared/StatCard';
import { Users, GraduationCap, ClipboardCheck, Sparkles } from 'lucide-react';
import { getPerformanceSummary } from '../../services/gemini';
import { StatsService } from '../../services/statsService';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface AdminDashboardProps {
  state: AppState;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ state }) => {
  const [aiSummary, setAiSummary] = useState<string>("Loading AI insights...");
  const [liveStats, setLiveStats] = useState({
    studentCount: 0,
    teacherCount: 0,
    classCount: 0,
    avgAttendance: '0%'
  });

  useEffect(() => {
    const fetchAllData = async () => {
      try {
        const stats = await StatsService.getAdminStats();
        setLiveStats(stats);

        const summary = await getPerformanceSummary({
          studentCount: stats.studentCount,
          teacherCount: stats.teacherCount,
          avgAttendance: stats.avgAttendance,
          recentScores: state.results.map(r => r.marks)
        });
        setAiSummary(summary);
      } catch (err) {
        console.error("Dashboard fetch error:", err);
      }
    };
    fetchAllData();
  }, [state.results]);

  const chartData = [
    { name: 'Grade 9', students: 120, attendance: 95 },
    { name: 'Grade 10', students: 85, attendance: 88 },
    { name: 'Grade 11', students: 70, attendance: 92 },
    { name: 'Grade 12', students: 65, attendance: 90 },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard label="Total Students" value={liveStats.studentCount} icon={<GraduationCap size={24} />} color="bg-blue-600" />
        <StatCard label="Total Teachers" value={liveStats.teacherCount} icon={<Users size={24} />} color="bg-cyan-600" />
        <StatCard label="Avg Attendance" value={liveStats.avgAttendance} icon={<ClipboardCheck size={24} />} color="bg-indigo-600" />
        <StatCard label="Classes" value={liveStats.classCount} icon={<Users size={24} />} color="bg-violet-600" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-4">Enrollment & Attendance by Grade</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="students" fill="#1e3a8a" radius={[4, 4, 0, 0]} />
                <Bar dataKey="attendance" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-900 to-indigo-900 p-6 rounded-xl text-white shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <Sparkles size={100} />
          </div>
          <div className="relative z-10">
            <h3 className="text-lg font-bold flex items-center mb-4">
              <Sparkles className="mr-2 text-blue-300" size={20} />
              AI Academy Insights
            </h3>
            <p className="text-blue-100 text-sm leading-relaxed italic">
              "{aiSummary}"
            </p>
            <div className="mt-6 pt-6 border-t border-white/10">
              <p className="text-xs text-blue-300 uppercase font-bold tracking-widest">Powered by Gemini AI</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
