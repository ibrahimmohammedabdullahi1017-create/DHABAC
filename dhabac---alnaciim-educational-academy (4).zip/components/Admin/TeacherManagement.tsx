
import React, { useState, useRef } from 'react';
import { Teacher, UserRole } from '../../types';
// Fixed missing Plus import from lucide-react
import { Search, Plus, UserPlus, Edit2, Trash2, X, Save, Camera, Loader2, CheckCircle2 } from 'lucide-react';
import { ProfileService } from '../../services/profileService';

interface TeacherManagementProps {
  teachers: Teacher[];
  onAdd: (teacher: Teacher) => void;
  onUpdate: (teacher: Teacher) => void;
  onDelete: (id: string) => void;
}

const TeacherManagement: React.FC<TeacherManagementProps> = ({ teachers, onAdd, onUpdate, onDelete }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    subject: '',
    id: '',
    password: '123',
    avatar: ''
  });

  const filteredTeachers = teachers.filter(t => 
    t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const preview = await ProfileService.convertToBase64(file);
      setFormData(prev => ({ ...prev, avatar: preview }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    try {
      if (editingTeacher) {
        const finalAvatar = await ProfileService.updateProfile(formData.id, formData, selectedFile || undefined);
        onUpdate({ ...editingTeacher, ...formData, avatar: finalAvatar });
      } else {
        // Correcting property name from id_number to idNumber to match ProfileService.createProfile interface
        const finalAvatar = await ProfileService.createProfile({
          idNumber: formData.id,
          name: formData.name,
          role: UserRole.TEACHER,
          subject: formData.subject,
          password: formData.password
        }, selectedFile || undefined);

        const newTeacher: Teacher = {
          id: formData.id,
          name: formData.name,
          role: UserRole.TEACHER,
          subject: formData.subject,
          password: formData.password,
          avatar: finalAvatar,
          assignedClasses: []
        };
        onAdd(newTeacher);
      }
      closeModal();
    } catch (err: any) {
      alert('Cilad ayaa dhacday: ' + err.message);
    } finally {
      setIsSaving(false);
    }
  };

  const openEdit = (teacher: Teacher) => {
    setEditingTeacher(teacher);
    setFormData({
      name: teacher.name,
      subject: teacher.subject,
      id: teacher.id,
      password: teacher.password || '123',
      avatar: teacher.avatar || ''
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingTeacher(null);
    setSelectedFile(null);
    setFormData({ name: '', subject: '', id: '', password: '123', avatar: '' });
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="relative max-w-md w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Raadi Macallin, ID ama Maaddo..."
            className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500 text-sm font-bold shadow-sm outline-none transition-all"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-blue-900 text-white px-6 py-3 rounded-2xl font-black text-sm flex items-center justify-center hover:bg-blue-800 transition-all shadow-lg active:scale-95"
        >
          <UserPlus size={18} className="mr-2" /> Ku dar Macallin Cusub
        </button>
      </div>

      <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
              <tr>
                <th className="px-8 py-5">Macallinka (Teacher)</th>
                <th className="px-8 py-5">Maaddada (Subject)</th>
                <th className="px-8 py-5">Classes</th>
                <th className="px-8 py-5 text-right">Ficil (Actions)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTeachers.length > 0 ? filteredTeachers.map(teacher => (
                <tr key={teacher.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-8 py-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-2xl bg-blue-100 overflow-hidden flex items-center justify-center text-blue-900 font-black border-2 border-white shadow-sm">
                        {teacher.avatar ? (
                          <img src={teacher.avatar} className="w-full h-full object-cover" />
                        ) : (
                          teacher.name.charAt(0)
                        )}
                      </div>
                      <div>
                        <p className="font-bold text-slate-800 text-base">{teacher.name}</p>
                        <p className="text-[10px] text-slate-400 font-black uppercase tracking-tighter">ID: {teacher.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className="bg-indigo-50 text-indigo-700 px-3 py-1.5 rounded-xl text-[10px] font-black border border-indigo-100 uppercase tracking-widest">
                      {teacher.subject}
                    </span>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex flex-wrap gap-1">
                      {teacher.assignedClasses.length > 0 ? teacher.assignedClasses.map(c => (
                        <span key={c} className="text-[9px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                          {c}
                        </span>
                      )) : (
                        <span className="text-[10px] text-slate-300 italic">No classes</span>
                      )}
                    </div>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <button 
                        onClick={() => openEdit(teacher)}
                        className="p-2.5 text-blue-600 hover:bg-blue-50 rounded-xl transition-all active:scale-90"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button 
                        onClick={() => {
                          if(window.confirm(`Ma hubtaa inaad tirtirto macallinka ${teacher.name}?`)) onDelete(teacher.id);
                        }}
                        className="p-2.5 text-red-600 hover:bg-red-50 rounded-xl transition-all active:scale-90"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={4} className="px-8 py-20 text-center">
                    <p className="text-slate-400 font-bold uppercase text-xs tracking-widest">Ma jiro macallin la helay.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 border border-slate-100">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center space-x-3">
                 <div className="p-2 bg-blue-900 text-white rounded-xl">
                   <UserPlus size={20} />
                 </div>
                 <h3 className="text-xl font-black text-slate-800">
                   {editingTeacher ? 'Cusbooneysii Macallin' : 'Ku dar Macallin'}
                 </h3>
              </div>
              <button onClick={closeModal} className="text-slate-400 hover:text-slate-600 p-2 bg-white rounded-xl border border-slate-200 transition-all"><X size={20} /></button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-8 space-y-5">
              <div className="flex justify-center mb-6">
                <div className="relative group">
                  <div className="w-28 h-28 rounded-3xl bg-slate-100 overflow-hidden border-4 border-white shadow-xl relative group-hover:brightness-90 transition-all">
                    {formData.avatar ? (
                      <img src={formData.avatar} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-slate-300">
                        <Camera size={32} strokeWidth={1.5} />
                        <span className="text-[8px] font-black uppercase tracking-widest mt-1">Photo</span>
                      </div>
                    )}
                  </div>
                  {/* Plus icon is now correctly imported */}
                  <button 
                    type="button" 
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white rounded-3xl"
                  >
                    <Plus size={24} />
                  </button>
                  <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Magaca Buuxa (Teacher Name)</label>
                  <input 
                    type="text" 
                    required
                    placeholder="Geli magaca macallinka"
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none font-bold text-slate-800 transition-all"
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Maaddada uu Dhigo (Subject)</label>
                  <input 
                    type="text" 
                    required
                    placeholder="Tusaale: Mathematics"
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none font-bold text-slate-800 transition-all"
                    value={formData.subject}
                    onChange={e => setFormData({...formData, subject: e.target.value})}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Teacher ID</label>
                    <input 
                      type="text" 
                      required
                      disabled={!!editingTeacher}
                      placeholder="e.g T-101"
                      className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none font-bold text-slate-800 transition-all disabled:opacity-50"
                      value={formData.id}
                      onChange={e => setFormData({...formData, id: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Password</label>
                    <input 
                      type="text" 
                      required
                      placeholder="••••••••"
                      className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none font-bold text-slate-800 transition-all"
                      value={formData.password}
                      onChange={e => setFormData({...formData, password: e.target.value})}
                    />
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <button 
                  type="submit"
                  disabled={isSaving}
                  className={`w-full py-4 rounded-2xl font-black shadow-xl transition-all flex items-center justify-center space-x-2 ${
                    isSaving ? 'bg-blue-800/80 text-white/50 cursor-wait' : 'bg-blue-900 text-white hover:bg-blue-800 active:scale-95'
                  }`}
                >
                  {isSaving ? <Loader2 className="animate-spin" size={20} /> : <CheckCircle2 size={20} />}
                  <span>{isSaving ? 'Kaydinaya Cloud-ka...' : (editingTeacher ? 'Cusbooneysii Xogta' : 'Xaree Macallinka')}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeacherManagement;
