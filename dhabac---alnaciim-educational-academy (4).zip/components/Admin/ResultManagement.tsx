
import React, { useState } from 'react';
import { ExamResult, AppState, Student } from '../../types';
import { Search, Edit2, Trash2, Save, X, FileText } from 'lucide-react';

interface ResultManagementProps {
  state: AppState;
  onUpdate: (results: ExamResult[]) => void;
  onDelete: (id: string) => void;
}

const ResultManagement: React.FC<ResultManagementProps> = ({ state, onUpdate, onDelete }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editMarks, setEditMarks] = useState<number>(0);

  const filteredResults = state.results.filter(r => {
    const student = state.students.find(s => s.id === r.studentId);
    return (
      (student?.name.toLowerCase().includes(searchTerm.toLowerCase()) || '') ||
      r.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.title?.toLowerCase().includes(searchTerm.toLowerCase()) || '')
    );
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const handleStartEdit = (result: ExamResult) => {
    setEditingId(result.id);
    setEditMarks(result.marks);
  };

  const handleSaveEdit = (result: ExamResult) => {
    // Calculate new grade based on edited marks
    const percentage = (editMarks / result.maxMarks) * 100;
    let grade = 'F';
    if (percentage >= 90) grade = 'A+';
    else if (percentage >= 80) grade = 'A';
    else if (percentage >= 70) grade = 'B';
    else if (percentage >= 60) grade = 'C';
    else if (percentage >= 50) grade = 'D';

    onUpdate([{ ...result, marks: editMarks, grade }]);
    setEditingId(null);
  };

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden animate-in fade-in duration-500">
      <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <FileText className="text-indigo-600" />
          <h3 className="text-xl font-black text-slate-800">Maamulista Natiijooyinka (Admin)</h3>
        </div>
        <div className="relative max-w-sm w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Raadi arday, maaddo ama imtixaan..."
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-medium"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
            <tr>
              <th className="px-6 py-4">Student</th>
              <th className="px-6 py-4">Assessment</th>
              <th className="px-6 py-4 text-center">Marks</th>
              <th className="px-6 py-4 text-center">Grade</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {filteredResults.length > 0 ? filteredResults.map(result => {
              const student = state.students.find(s => s.id === result.studentId);
              return (
                <tr key={result.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <p className="font-bold text-slate-800">{student?.name || 'Unknown'}</p>
                    <p className="text-[10px] text-slate-400 font-bold uppercase">{result.subject}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="font-medium text-slate-700">{result.title}</p>
                    <p className="text-[10px] text-slate-400">{result.date}</p>
                  </td>
                  <td className="px-6 py-4 text-center">
                    {editingId === result.id ? (
                      <input 
                        type="number" 
                        max={result.maxMarks}
                        value={editMarks}
                        onChange={(e) => setEditMarks(parseInt(e.target.value) || 0)}
                        className="w-16 px-2 py-1 border border-indigo-200 rounded-lg text-center font-black focus:outline-none"
                      />
                    ) : (
                      <span className="font-black text-slate-800">{result.marks} <span className="text-slate-300 font-medium">/ {result.maxMarks}</span></span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="inline-block w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-black text-xs text-slate-700 border border-slate-200">
                      {result.grade}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      {editingId === result.id ? (
                        <button 
                          onClick={() => handleSaveEdit(result)}
                          className="p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                        >
                          <Save size={14} />
                        </button>
                      ) : (
                        <button 
                          onClick={() => handleStartEdit(result)}
                          className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        >
                          <Edit2 size={14} />
                        </button>
                      )}
                      <button 
                        onClick={() => onDelete(result.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            }) : (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-slate-400 font-medium italic">
                  Ma jiraan natiijooyin loo diwaangeliyey ardayda.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ResultManagement;
