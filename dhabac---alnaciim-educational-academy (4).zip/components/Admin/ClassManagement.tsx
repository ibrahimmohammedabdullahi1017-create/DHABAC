
import React, { useState } from 'react';
import { SchoolClass, Teacher, Student } from '../../types';
import { BookOpen, Plus, Users, Edit2, Trash2, X, Save, UserCheck, Filter, Search } from 'lucide-react';

interface ClassManagementProps {
  classes: SchoolClass[];
  teachers: Teacher[];
  students: Student[];
  onAdd: (cls: SchoolClass) => void;
  onUpdate: (cls: SchoolClass) => void;
  onDelete: (id: string) => void;
}

const ClassManagement: React.FC<ClassManagementProps> = ({ classes, teachers, students, onAdd, onUpdate, onDelete }) => {
  const [showModal, setShowModal] = useState(false);
  const [editingClass, setEditingClass] = useState<SchoolClass | null>(null);
  const [teacherFilter, setTeacherFilter] = useState<string>('all');
  const [formData, setFormData] = useState({
    name: '',
    teacherId: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingClass) {
      onUpdate({ ...editingClass, ...formData });
    } else {
      const newClass: SchoolClass = {
        id: `c${Date.now()}`,
        name: formData.name,
        teacherId: formData.teacherId,
        students: []
      };
      onAdd(newClass);
    }
    closeModal();
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingClass(null);
    setFormData({ name: '', teacherId: '' });
  };

  const openEdit = (cls: SchoolClass) => {
    setEditingClass(cls);
    setFormData({ name: cls.name, teacherId: cls.teacherId || '' });
    setShowModal(true);
  };

  const filteredClasses = classes.filter(cls => {
    if (teacherFilter === 'all') return true;
    return cls.teacherId === teacherFilter;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Header & Filters */}
      <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-blue-900 text-white rounded-2xl shadow-lg">
            <BookOpen size={24} />
          </div>
          <div>
            <h3 className="text-xl font-black text-slate-800 tracking-tight">Maamulista Fasallada</h3>
            <p className="text-sm text-slate-500 font-medium">Habee oo kormeer fasallada dugsiga.</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-4">
          {/* Teacher Filter Dropdown */}
          <div className="relative w-full sm:w-64">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
              <Filter size={16} />
            </div>
            <select
              value={teacherFilter}
              onChange={(e) => setTeacherFilter(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none font-bold text-sm appearance-none cursor-pointer transition-all"
            >
              <option value="all">Dhammaan Macallimiinta</option>
              {teachers.map(t => (
                <option key={t.id} value={t.id}>{t.name}</option>
              ))}
            </select>
            <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
              <Plus size={14} className="rotate-45" />
            </div>
          </div>

          <button 
            onClick={() => setShowModal(true)}
            className="w-full sm:w-auto bg-blue-900 text-white px-6 py-3.5 rounded-2xl font-black text-sm flex items-center justify-center hover:bg-blue-800 transition-all shadow-lg active:scale-95"
          >
            <Plus size={18} className="mr-2" /> Fasal Cusub
          </button>
        </div>
      </div>

      {/* Class Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredClasses.length > 0 ? filteredClasses.map(cls => {
          const classTeacher = teachers.find(t => t.id === cls.teacherId);
          const studentCount = students.filter(s => s.className === cls.name).length;
          
          return (
            <div key={cls.id} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all group animate-in zoom-in-95 duration-300">
              <div className="flex justify-between items-start mb-6">
                <div className="w-12 h-12 bg-blue-50 text-blue-900 rounded-2xl flex items-center justify-center font-black text-lg border border-blue-100">
                  {cls.name.charAt(0)}
                </div>
                <div className="flex space-x-1">
                  <button onClick={() => openEdit(cls)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                    <Edit2 size={14} />
                  </button>
                  <button onClick={() => {
                    if(window.confirm(`Ma hubtaa inaad tirtirto fasalka ${cls.name}?`)) {
                      onDelete(cls.id);
                    }
                  }} className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
              
              <h4 className="text-xl font-black text-slate-800 mb-1">{cls.name}</h4>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-6">Classroom Registry</p>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-sm">
                  <div className="p-2 bg-slate-50 text-slate-400 rounded-lg">
                    <UserCheck size={16} />
                  </div>
                  <div className="flex-1">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">Assigned Teacher</p>
                    <p className="font-bold text-slate-700 truncate max-w-[150px]">{classTeacher?.name || 'No Teacher Assigned'}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3 text-sm">
                  <div className="p-2 bg-slate-50 text-slate-400 rounded-lg">
                    <Users size={16} />
                  </div>
                  <div>
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">Active Students</p>
                    <p className="font-bold text-slate-700">{studentCount} Students</p>
                  </div>
                </div>
              </div>
            </div>
          );
        }) : (
          <div className="col-span-full py-20 bg-white rounded-3xl border border-dashed border-slate-200 text-center">
            <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-300 mx-auto mb-4">
              <Search size={32} />
            </div>
            <h4 className="text-lg font-bold text-slate-800">Ma jiraan fasallo la helay</h4>
            <p className="text-slate-400 text-sm mt-1">Fadlan hubi filter-ka macallinka ama ku dar fasal cusub.</p>
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-6 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
              <h3 className="text-xl font-black text-slate-800">
                {editingClass ? 'Wax ka baddal Fasalka' : 'Abuur Fasal Cusub'}
              </h3>
              <button onClick={closeModal} className="text-slate-400 hover:text-slate-600 p-2"><X size={20} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-8 space-y-5">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Magaca Fasalka (e.g Grade 10-A)</label>
                <input 
                  type="text" 
                  required
                  placeholder="Geli magaca fasalka"
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none font-bold text-slate-800"
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">U qoondee Macallin</label>
                <div className="relative">
                  <select 
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none font-bold appearance-none text-slate-800 cursor-pointer"
                    value={formData.teacherId}
                    onChange={e => setFormData({...formData, teacherId: e.target.value})}
                  >
                    <option value="">Dooro Macallin (Optional)</option>
                    {teachers.map(t => (
                      <option key={t.id} value={t.id}>{t.name} ({t.subject})</option>
                    ))}
                  </select>
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">
                    <Plus size={14} className="rotate-45" />
                  </div>
                </div>
              </div>
              <button 
                type="submit"
                className="w-full bg-blue-900 text-white py-4 rounded-2xl font-black shadow-lg hover:bg-blue-800 transition-all flex items-center justify-center mt-4 active:scale-95"
              >
                <Save size={18} className="mr-2" /> {editingClass ? 'Keydi Isbedelka' : 'Xaree Fasalka'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ClassManagement;
