
import React from 'react';
import { Student } from '../../types';
import { UserCheck, UserX, Clock, Search, GraduationCap } from 'lucide-react';

interface RegistrationManagementProps {
  students: Student[];
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

const RegistrationManagement: React.FC<RegistrationManagementProps> = ({ students, onApprove, onReject }) => {
  const pendingStudents = students.filter(s => s.status === 'pending');

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-8 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-blue-900 text-white rounded-2xl">
              <Clock size={24} />
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-800">Codsiyada Sugaya (Pending Registrations)</h3>
              <p className="text-sm text-slate-500 font-medium">Hubi oo ogolaaw ardayda cusub ee is diwaangelisay.</p>
            </div>
          </div>
          <div className="bg-blue-100 text-blue-900 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest">
            {pendingStudents.length} Codsi
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
              <tr>
                <th className="px-8 py-5">Ardayga (Student)</th>
                <th className="px-8 py-5">ID Number</th>
                <th className="px-8 py-5">Fasalka (Class)</th>
                <th className="px-8 py-5 text-right">Ficil (Actions)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {pendingStudents.length > 0 ? pendingStudents.map(student => (
                <tr key={student.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-8 py-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center text-blue-900 font-black">
                        {student.name.charAt(0)}
                      </div>
                      <p className="font-bold text-slate-800">{student.name}</p>
                    </div>
                  </td>
                  <td className="px-8 py-6 text-sm font-bold text-slate-600">{student.idNumber}</td>
                  <td className="px-8 py-6">
                    <span className="bg-slate-100 px-3 py-1 rounded-lg text-xs font-black text-slate-600">
                      {student.className}
                    </span>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <button 
                        onClick={() => onApprove(student.id)}
                        className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-xl text-xs font-black hover:bg-green-700 transition-all shadow-md active:scale-95"
                      >
                        <UserCheck size={14} />
                        <span>Ogolaaw</span>
                      </button>
                      <button 
                        onClick={() => onReject(student.id)}
                        className="flex items-center space-x-2 px-4 py-2 bg-red-50 text-red-600 rounded-xl text-xs font-black hover:bg-red-100 transition-all active:scale-95"
                      >
                        <UserX size={14} />
                        <span>Diid</span>
                      </button>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={4} className="px-8 py-20 text-center">
                    <div className="flex flex-col items-center">
                      <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-200 mb-4">
                        <GraduationCap size={40} />
                      </div>
                      <p className="text-slate-400 font-bold uppercase text-xs tracking-widest">Ma jiraan codsiyo cusub hadda.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default RegistrationManagement;
