
import React, { useState, useRef } from 'react';
import { User, UserRole, Student, Teacher } from '../../types';
import { User as UserIcon, Camera, Save, ShieldCheck, Mail, Phone, BookOpen, GraduationCap, Loader2, CheckCircle2 } from 'lucide-react';
import { ProfileService } from '../../services/profileService';

interface ProfileViewProps {
  user: User;
  onUpdate: (updatedUser: any) => void;
  isAdminView?: boolean;
}

const ProfileView: React.FC<ProfileViewProps> = ({ user, onUpdate, isAdminView = false }) => {
  const [formData, setFormData] = useState({
    name: user.name,
    avatar: user.avatar || '',
    email: user.email || '',
    phone: user.phone || '',
    className: (user as Student).className || '',
    subject: (user as Teacher).subject || '',
  });

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      try {
        // Still generate preview for instant UI feedback
        const preview = await ProfileService.convertToBase64(file);
        setFormData(prev => ({ ...prev, avatar: preview }));
      } catch (err) {
        alert('Cilad ayaa dhacday soo gelinta sawirka.');
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      // Pass the raw file for real cloud storage upload
      const finalAvatarUrl = await ProfileService.updateProfile(user.id, formData, selectedFile || undefined);
      
      onUpdate({ ...user, ...formData, avatar: finalAvatarUrl });
      setSuccess(true);
      setSelectedFile(null);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err: any) {
      console.error(err);
      alert('Cilad ayaa dhacday keydinta xogta: ' + err.message);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-white rounded-[2.5rem] shadow-xl border border-slate-100 overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-blue-900 to-indigo-800 relative">
          <div className="absolute -bottom-16 left-10">
            <div className="relative group">
              <div className="w-32 h-32 rounded-3xl bg-white p-1 shadow-2xl overflow-hidden border-4 border-white">
                {formData.avatar ? (
                  <img src={formData.avatar} alt="Profile" className="w-full h-full object-cover rounded-2xl" />
                ) : (
                  <div className="w-full h-full bg-slate-100 rounded-2xl flex items-center justify-center text-slate-300">
                    <UserIcon size={48} />
                  </div>
                )}
                <button 
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white rounded-3xl"
                >
                  <Camera size={24} className="mb-1" />
                  <span className="text-[10px] font-black uppercase">Change</span>
                </button>
              </div>
              <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
            </div>
          </div>
        </div>

        <div className="pt-20 px-10 pb-10">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">{user.name}</h2>
              <div className="flex items-center space-x-2 mt-1">
                <span className="bg-blue-50 text-blue-700 px-3 py-1 rounded-lg text-xs font-black border border-blue-100 uppercase tracking-widest">
                  {user.role}
                </span>
                <span className="text-slate-400 font-bold text-xs uppercase tracking-tighter">ID: {user.id}</span>
              </div>
            </div>
            {success && (
              <div className="flex items-center text-green-600 font-black text-sm bg-green-50 px-4 py-2 rounded-xl border border-green-100 animate-bounce">
                <CheckCircle2 size={20} className="mr-2" /> Xogta waa la keydiyay!
              </div>
            )}
          </div>

          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <h4 className="text-xs font-black uppercase tracking-widest border-b pb-2 text-slate-400 flex items-center">
                <UserIcon size={14} className="mr-2" /> Personal Information
              </h4>
              
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Full Name</label>
                <input 
                  type="text"
                  required
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none font-bold text-slate-800 transition-all"
                  value={formData.name}
                  onChange={e => setFormData(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Email Address</label>
                <input 
                  type="email"
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none font-bold text-slate-800 transition-all"
                  value={formData.email}
                  onChange={e => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="email@alnaciim.com"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Phone Number</label>
                <input 
                  type="tel"
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 outline-none font-bold text-slate-800 transition-all"
                  value={formData.phone}
                  onChange={e => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                  placeholder="+252 ..."
                />
              </div>
            </div>

            <div className="space-y-6">
              <h4 className="text-xs font-black uppercase tracking-widest border-b pb-2 text-slate-400 flex items-center">
                <ShieldCheck size={14} className="mr-2" /> Academic Details
              </h4>

              {user.role === UserRole.STUDENT && (
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Current Class</label>
                  <input 
                    type="text"
                    disabled={!isAdminView}
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold text-slate-800 outline-none disabled:opacity-50"
                    value={formData.className}
                    onChange={e => setFormData(prev => ({ ...prev, className: e.target.value }))}
                  />
                </div>
              )}

              {user.role === UserRole.TEACHER && (
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Subject Specialization</label>
                  <input 
                    type="text"
                    disabled={!isAdminView}
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold text-slate-800 outline-none disabled:opacity-50"
                    value={formData.subject}
                    onChange={e => setFormData(prev => ({ ...prev, subject: e.target.value }))}
                  />
                </div>
              )}

              <div className="bg-blue-50 p-6 rounded-3xl border border-blue-100 mt-4">
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-white rounded-xl text-blue-600 shadow-sm">
                    <BookOpen size={18} />
                  </div>
                  <div>
                    <h5 className="font-black text-blue-900 text-sm">Alnaciim Security Protocol</h5>
                    <p className="text-[10px] text-blue-700/70 font-medium leading-relaxed mt-1">
                      Xogtaada waxaa lagu kaydiyaa Supabase Cloud Storage. Isbedeladaada waa kuwo ammaan ah oo xogtaada lagu badbaadinayo.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="md:col-span-2 flex justify-end pt-6">
              <button 
                type="submit"
                disabled={isSaving}
                className="w-full md:w-auto bg-blue-900 text-white px-12 py-5 rounded-2xl font-black text-lg shadow-2xl transform hover:-translate-y-1 active:translate-y-0.5 transition-all flex items-center justify-center"
              >
                {isSaving ? <Loader2 className="animate-spin mr-3" size={24} /> : <Save className="mr-3" size={24} />}
                {isSaving ? 'Kaydinaya Cloud-ka...' : 'Save Profile Changes'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ProfileView;
