
import React, { useState, useEffect } from 'react';
import { Student, AttendanceRecord } from '../../types';
import { Check, X, Clock, Calendar, ClipboardCheck, User, Save, Loader2, PartyPopper } from 'lucide-react';

interface AttendanceTrackerProps {
  students: Student[];
  onSave: (records: AttendanceRecord[]) => void;
  className: string;
}

const AttendanceTracker: React.FC<AttendanceTrackerProps> = ({ students, onSave, className }) => {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [attendance, setAttendance] = useState<Record<string, 'Present' | 'Absent' | 'Late'>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  // Sync attendance state when students change (e.g. switching classes)
  useEffect(() => {
    setAttendance(Object.fromEntries(students.map(s => [s.id, 'Present'])));
  }, [students]);

  const handleStatusChange = (studentId: string, status: 'Present' | 'Absent' | 'Late') => {
    setAttendance(prev => ({ ...prev, [studentId]: status }));
  };

  const handleSubmit = async () => {
    if (students.length === 0) return;
    
    setIsSubmitting(true);
    
    // Simulate a small delay for cloud sync feel
    await new Promise(resolve => setTimeout(resolve, 800));

    const records: AttendanceRecord[] = students.map(s => ({
      id: Math.random().toString(36).substr(2, 9),
      studentId: s.id,
      studentName: s.name,
      date,
      status: attendance[s.id] || 'Present',
      className
    }));
    
    onSave(records);
    setIsSubmitting(false);
    setShowSuccess(true);
    
    // Hide success message after 3 seconds
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const stats = {
    present: Object.values(attendance).filter(s => s === 'Present').length,
    absent: Object.values(attendance).filter(s => s === 'Absent').length,
    late: Object.values(attendance).filter(s => s === 'Late').length,
  };

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="p-8 bg-slate-50/50 border-b border-slate-100">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
            <div className="p-4 bg-blue-900 text-white rounded-2xl shadow-xl transform rotate-2">
              <ClipboardCheck size={28} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-slate-900 tracking-tight">Attendence-ka Maalinlaha ah</h3>
              <p className="text-sm text-slate-500 font-medium">Fasalka: <span className="text-blue-600 font-bold">{className || 'No Class Selected'}</span></p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-xl border border-slate-100 shadow-sm">
               <div className="flex items-center space-x-1 text-green-600 font-black text-xs">
                 <Check size={14} /> <span>{stats.present} P</span>
               </div>
               <div className="w-px h-3 bg-slate-200"></div>
               <div className="flex items-center space-x-1 text-red-600 font-black text-xs">
                 <X size={14} /> <span>{stats.absent} A</span>
               </div>
               <div className="w-px h-3 bg-slate-200"></div>
               <div className="flex items-center space-x-1 text-amber-600 font-black text-xs">
                 <Clock size={14} /> <span>{stats.late} L</span>
               </div>
            </div>

            <div className="flex items-center space-x-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-sm group hover:border-blue-400 transition-colors">
              <Calendar size={20} className="text-slate-400 group-hover:text-blue-600 transition-colors" />
              <input 
                type="date" 
                value={date} 
                onChange={(e) => setDate(e.target.value)}
                className="text-sm font-black text-slate-800 focus:outline-none cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-100 text-[10px] font-black text-slate-400 uppercase tracking-widest">
            <tr>
              <th className="px-10 py-5">Ardayga (Student)</th>
              <th className="px-10 py-5">Xaaladda (Status)</th>
              <th className="px-10 py-5 text-center">Calaamadi (Actions)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {students.length > 0 ? students.map(student => (
              <tr key={student.id} className="group hover:bg-slate-50/50 transition-colors">
                <td className="px-10 py-6">
                   <div className="flex items-center space-x-4">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm shadow-sm border-2 border-white transition-all ${
                        attendance[student.id] === 'Present' ? 'bg-green-100 text-green-700' :
                        attendance[student.id] === 'Absent' ? 'bg-red-100 text-red-700' :
                        'bg-amber-100 text-amber-700'
                      }`}>
                        {student.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-slate-800 text-base">{student.name}</p>
                        <p className="text-[10px] text-slate-400 font-black tracking-tight uppercase">ID: {student.idNumber}</p>
                      </div>
                   </div>
                </td>
                <td className="px-10 py-6">
                  <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest shadow-sm border ${
                    attendance[student.id] === 'Present' ? 'bg-green-50 text-green-700 border-green-100' :
                    attendance[student.id] === 'Absent' ? 'bg-red-50 text-red-700 border-red-100' :
                    'bg-amber-50 text-amber-700 border-amber-100'
                  }`}>
                    {attendance[student.id] || 'Present'}
                  </span>
                </td>
                <td className="px-10 py-6">
                  <div className="flex items-center justify-center space-x-3">
                    <button 
                      onClick={() => handleStatusChange(student.id, 'Present')}
                      title="Present"
                      className={`p-3 rounded-2xl transition-all duration-300 transform active:scale-90 ${
                        attendance[student.id] === 'Present' 
                          ? 'bg-green-600 text-white shadow-lg shadow-green-600/20 scale-110' 
                          : 'bg-white text-slate-300 border border-slate-100 hover:border-green-200 hover:text-green-500'
                      }`}
                    >
                      <Check size={18} strokeWidth={3} />
                    </button>
                    <button 
                      onClick={() => handleStatusChange(student.id, 'Late')}
                      title="Late"
                      className={`p-3 rounded-2xl transition-all duration-300 transform active:scale-90 ${
                        attendance[student.id] === 'Late' 
                          ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/20 scale-110' 
                          : 'bg-white text-slate-300 border border-slate-100 hover:border-amber-200 hover:text-amber-500'
                      }`}
                    >
                      <Clock size={18} strokeWidth={3} />
                    </button>
                    <button 
                      onClick={() => handleStatusChange(student.id, 'Absent')}
                      title="Absent"
                      className={`p-3 rounded-2xl transition-all duration-300 transform active:scale-90 ${
                        attendance[student.id] === 'Absent' 
                          ? 'bg-red-600 text-white shadow-lg shadow-red-600/20 scale-110' 
                          : 'bg-white text-slate-300 border border-slate-100 hover:border-red-200 hover:text-red-500'
                      }`}
                    >
                      <X size={18} strokeWidth={3} />
                    </button>
                  </div>
                </td>
              </tr>
            )) : (
              <tr>
                <td colSpan={3} className="px-10 py-20 text-center">
                   <div className="flex flex-col items-center">
                      <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-200 mb-4 border border-slate-100">
                        <User size={32} />
                      </div>
                      <p className="text-slate-400 font-bold uppercase text-xs tracking-widest">Ma jiraan arday fasalkan ku qoran</p>
                   </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="p-10 bg-slate-50 border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-white rounded-2xl shadow-sm border border-slate-200">
             <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Students</p>
             <p className="text-lg font-black text-slate-800">{students.length}</p>
          </div>
          {showSuccess && (
            <div className="flex items-center space-x-2 text-green-600 font-black text-sm animate-bounce">
              <PartyPopper size={20} />
              <span>Si guul leh ayaa loo kaydiyay!</span>
            </div>
          )}
        </div>

        <button 
          onClick={handleSubmit}
          disabled={isSubmitting || students.length === 0}
          className={`group w-full md:w-auto px-12 py-5 rounded-2xl font-black text-lg shadow-2xl transform transition-all flex items-center justify-center ${
            isSubmitting 
              ? 'bg-blue-800/80 text-white/50 cursor-wait' 
              : 'bg-blue-900 text-white hover:bg-blue-800 hover:-translate-y-1 active:translate-y-0.5'
          }`}
        >
          {isSubmitting ? (
            <Loader2 className="mr-3 animate-spin" size={24} />
          ) : (
            <Save className="mr-3 group-hover:scale-110 transition-transform" size={24} />
          )}
          {isSubmitting ? 'Kaydinaya...' : 'Submit Attendence'}
        </button>
      </div>
    </div>
  );
};

export default AttendanceTracker;
