
import React, { useEffect, useState, useRef } from 'react';

interface StatCardProps {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
}

export const StatCard: React.FC<StatCardProps> = ({ label, value, icon, color }) => {
  const [displayValue, setDisplayValue] = useState<number | string>(0);
  const animationRef = useRef<number>(0);

  useEffect(() => {
    // Determine target number
    let target = 0;
    let isPercentage = false;

    if (typeof value === 'number') {
      target = value;
    } else if (typeof value === 'string') {
      const numeric = parseInt(value);
      if (!isNaN(numeric)) {
        target = numeric;
        isPercentage = value.includes('%');
      } else {
        setDisplayValue(value);
        return;
      }
    }

    // Animation logic
    let start = 0;
    const duration = 1200; // 1.2 seconds
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Easing function: easeOutExpo
      const easedProgress = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      const currentCount = Math.floor(easedProgress * target);

      if (isPercentage) {
        setDisplayValue(`${currentCount}%`);
      } else {
        setDisplayValue(currentCount);
      }

      if (progress < 1) {
        animationRef.current = requestAnimationFrame(animate);
      } else {
        // Final catch to ensure exact value
        setDisplayValue(value);
      }
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [value]);

  return (
    <div className="bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100 flex items-center space-x-5 hover:shadow-xl hover:-translate-y-1 transition-all duration-500 group">
      <div className={`${color} p-4 rounded-2xl text-white shadow-lg group-hover:scale-110 group-hover:rotate-3 transition-all duration-500`}>
        {icon}
      </div>
      <div>
        <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">{label}</p>
        <p className="text-3xl font-black text-slate-900 tabular-nums">
          {displayValue}
        </p>
      </div>
    </div>
  );
};
