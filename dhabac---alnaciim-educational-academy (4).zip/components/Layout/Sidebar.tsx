
import React from 'react';
import { UserRole } from '../../types';
import { 
  LayoutDashboard, 
  Users, 
  GraduationCap, 
  ClipboardCheck, 
  FileText, 
  Settings, 
  LogOut, 
  BookOpen,
  Sparkles,
  UserPlus,
  X,
  BookMarked,
  ShieldCheck,
  ShieldAlert,
  UserCheck,
  User as UserIcon
} from 'lucide-react';

interface SidebarProps {
  role: UserRole;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
  schoolName: string;
  systemName: string;
  logoUrl?: string;
  isOpen: boolean;
  onClose: () => void;
  pendingCount?: number;
  currentUserId?: string;
}

const Sidebar: React.FC<SidebarProps> = ({ role, activeTab, setActiveTab, onLogout, schoolName, systemName, logoUrl, isOpen, onClose, pendingCount = 0, currentUserId }) => {
  const isSuperAdmin = currentUserId === 'admin';

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} />, roles: [UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT] },
    { id: 'profile', label: 'Profile', icon: <UserIcon size={20} />, roles: [UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT] },
    { id: 'registrations', label: 'Codsiyada', icon: <UserPlus size={20} />, roles: [UserRole.ADMIN], badge: pendingCount > 0 ? pendingCount : null },
    { id: 'admins', label: 'Managers', icon: <UserCheck size={20} />, roles: [UserRole.ADMIN], hide: !isSuperAdmin },
    { id: 'reading', label: 'Xogta Akhriska', icon: <BookMarked size={20} />, roles: [UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT] },
    { id: 'ai-teacher', label: 'Macallin AI', icon: <Sparkles size={20} />, roles: [UserRole.STUDENT] },
    { id: 'students', label: 'Students', icon: <GraduationCap size={20} />, roles: [UserRole.ADMIN, UserRole.TEACHER] },
    { id: 'teachers', label: 'Teachers', icon: <Users size={20} />, roles: [UserRole.ADMIN] },
    { id: 'classes', label: 'Classes', icon: <BookOpen size={20} />, roles: [UserRole.ADMIN] },
    { id: 'attendance', label: 'Attendance', icon: <ClipboardCheck size={20} />, roles: [UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT] },
    { id: 'results', label: 'Results', icon: <FileText size={20} />, roles: [UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT] },
    { id: 'backup', label: 'Digital Backup', icon: <ShieldCheck size={20} />, roles: [UserRole.ADMIN] },
    { id: 'settings', label: 'Settings', icon: <Settings size={20} />, roles: [UserRole.ADMIN] },
  ];

  const filteredItems = menuItems.filter(item => item.roles.includes(role) && !item.hide);

  const handleTabClick = (id: string) => {
    setActiveTab(id);
    if (window.innerWidth < 1024) {
      onClose();
    }
  };

  return (
    <>
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[60] lg:hidden transition-opacity"
          onClick={onClose}
        />
      )}

      <div className="fixed top-0 left-0 h-full w-72 text-white flex flex-col z-[70] shadow-2xl transition-transform duration-300 transform lg:translate-x-0"
           style={{ backgroundColor: 'var(--primary-color)', transform: isOpen ? 'translateX(0)' : 'translateX(-100%)' }}>
        
        <div className="p-6 flex items-center justify-between">
          <div>
            <div className="flex items-center space-x-3 mb-1">
              {logoUrl ? (
                <img src={logoUrl} alt="Logo" className="w-10 h-10 object-contain bg-white rounded-xl shadow-lg p-1" />
              ) : (
                <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-lg">
                  <GraduationCap style={{ color: 'var(--primary-color)' }} size={24} />
                </div>
              )}
              <span className="text-2xl font-black tracking-tighter">{systemName}</span>
            </div>
            <p className="text-[10px] uppercase text-blue-300 font-black tracking-widest opacity-80 line-clamp-1">{schoolName}</p>
          </div>
          <button 
            onClick={onClose}
            className="lg:hidden p-2 hover:bg-white/10 rounded-xl transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-2 overflow-y-auto custom-scrollbar">
          {filteredItems.map(item => (
            <button
              key={item.id}
              onClick={() => handleTabClick(item.id)}
              className={`w-full flex items-center justify-between px-5 py-4 rounded-2xl transition-all duration-300 group ${
                activeTab === item.id 
                  ? 'sidebar-active shadow-xl font-bold' 
                  : 'text-blue-100 hover:bg-white/10'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div className={`${activeTab === item.id ? 'text-primary' : 'text-blue-300 group-hover:text-white'} transition-colors`}>
                  {item.icon}
                </div>
                <span className="font-bold tracking-tight">{item.label}</span>
              </div>
              {item.badge && (
                <span className="bg-red-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full shadow-sm">
                  {item.badge}
                </span>
              )}
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-white/10 bg-black/5">
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center space-x-3 px-4 py-4 text-blue-300 hover:bg-red-500 hover:text-white rounded-2xl transition-all font-black uppercase text-xs tracking-widest border border-white/10 shadow-sm"
          >
            <LogOut size={16} />
            <span>Logout System</span>
          </button>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
