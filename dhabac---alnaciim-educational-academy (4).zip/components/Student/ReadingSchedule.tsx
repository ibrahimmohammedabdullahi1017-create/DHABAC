
import React from 'react';
import { Student, ReadingMaterial } from '../../types';
import { BookMarked, ArrowRight, ExternalLink, FileText, Calendar, Sparkles } from 'lucide-react';

interface ReadingScheduleProps {
  student: Student;
  lessons: ReadingMaterial[];
  onStartAI: (lesson: ReadingMaterial) => void;
}

const ReadingSchedule: React.FC<ReadingScheduleProps> = ({ student, lessons, onStartAI }) => {
  const myLessons = lessons.filter(l => l.className === student.className);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-2xl font-black text-slate-800 tracking-tight">Jadwalkaaga Akhriska</h3>
          <p className="text-sm text-slate-500 font-medium">Dhameystir akhriska PDF-yada si aad AI-ga uga gudubto imtixaanka.</p>
        </div>
        <div className="bg-blue-50 text-blue-900 px-4 py-2 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-blue-100">
          {myLessons.length} Active Lessons
        </div>
      </div>

      <div className="space-y-4">
        {myLessons.length > 0 ? myLessons.map((lesson, idx) => (
          <div key={lesson.id} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden group">
            <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-blue-900 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            
            <div className="flex items-start space-x-5 flex-1">
              <div className="p-4 bg-slate-50 text-slate-400 rounded-2xl group-hover:bg-blue-50 group-hover:text-blue-900 transition-colors shrink-0">
                <FileText size={28} />
              </div>
              <div>
                <h4 className="text-xl font-black text-slate-800 mb-1">{lesson.title}</h4>
                <div className="flex items-center space-x-4 mb-3">
                  <span className="flex items-center text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    <Calendar size={12} className="mr-1.5" /> {lesson.date}
                  </span>
                  <a 
                    href={lesson.pdfUrl} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="flex items-center text-[10px] font-black text-blue-600 uppercase tracking-widest hover:underline"
                  >
                    View Reading <ExternalLink size={10} className="ml-1" />
                  </a>
                </div>
                <p className="text-sm text-slate-500 font-medium max-w-xl line-clamp-2">{lesson.description}</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <button 
                onClick={() => onStartAI(lesson)}
                className="bg-indigo-900 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-indigo-900/10 hover:bg-indigo-800 hover:-translate-y-1 transition-all flex items-center justify-center group/btn"
              >
                <Sparkles size={16} className="mr-2 group-hover/btn:animate-pulse" /> Bilow Imtixaanka AI
              </button>
            </div>
          </div>
        )) : (
          <div className="py-20 bg-white rounded-3xl border border-dashed border-slate-100 text-center">
            <BookMarked size={48} className="mx-auto text-slate-100 mb-4" />
            <p className="text-slate-400 font-bold">Ma jiraan casharro laguu soo dhigay xilligan.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReadingSchedule;
