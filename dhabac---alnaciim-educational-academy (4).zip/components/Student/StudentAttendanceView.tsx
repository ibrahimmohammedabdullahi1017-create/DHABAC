
import React, { useState } from 'react';
import { AttendanceRecord, Student } from '../../types';
import { Search, Calendar, ClipboardCheck, CheckCircle2, XCircle, Clock, Filter } from 'lucide-react';

interface StudentAttendanceViewProps {
  student: Student;
  attendance: AttendanceRecord[];
}

const StudentAttendanceView: React.FC<StudentAttendanceViewProps> = ({ student, attendance }) => {
  const [searchTerm, setSearchTerm] = useState('');
  
  // Filter attendance for this specific student only
  const myAttendance = attendance.filter(a => a.studentId === student.id);
  
  const filteredAttendance = myAttendance.filter(a => 
    a.date.includes(searchTerm) || a.status.toLowerCase().includes(searchTerm.toLowerCase())
  ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const stats = {
    total: myAttendance.length,
    present: myAttendance.filter(a => a.status === 'Present').length,
    absent: myAttendance.filter(a => a.status === 'Absent').length,
    late: myAttendance.filter(a => a.status === 'Late').length,
  };

  const attendancePercentage = stats.total > 0 
    ? Math.round(((stats.present + (stats.late * 0.5)) / stats.total) * 100) 
    : 0;

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Attendance Summary Header */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center space-x-4">
          <div className="p-3 bg-blue-100 text-blue-900 rounded-2xl">
            <ClipboardCheck size={24} />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Attendance Rate</p>
            <p className="text-2xl font-black text-slate-800">{attendancePercentage}%</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center space-x-4">
          <div className="p-3 bg-green-100 text-green-700 rounded-2xl">
            <CheckCircle2 size={24} />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Present Days</p>
            <p className="text-2xl font-black text-slate-800">{stats.present}</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center space-x-4">
          <div className="p-3 bg-amber-100 text-amber-700 rounded-2xl">
            <Clock size={24} />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Late Arrivals</p>
            <p className="text-2xl font-black text-slate-800">{stats.late}</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center space-x-4">
          <div className="p-3 bg-red-100 text-red-700 rounded-2xl">
            <XCircle size={24} />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Absent Days</p>
            <p className="text-2xl font-black text-slate-800">{stats.absent}</p>
          </div>
        </div>
      </div>

      {/* Detailed List */}
      <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <Calendar className="text-blue-900" size={20} />
            <h3 className="text-lg font-black text-slate-800">Xogta Attendence-kaaga</h3>
          </div>
          <div className="relative max-w-sm w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input 
              type="text" 
              placeholder="Raadi taariikh (e.g 2024-03)..."
              className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs font-bold"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
              <tr>
                <th className="px-8 py-5">Taariikhda (Date)</th>
                <th className="px-8 py-5">Fasalka (Class)</th>
                <th className="px-8 py-5">Xaaladda (Status)</th>
                <th className="px-8 py-5 text-right">Fariin (Note)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAttendance.length > 0 ? filteredAttendance.map(record => (
                <tr key={record.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-8 py-6">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-blue-50 text-blue-900 rounded-lg group-hover:bg-blue-900 group-hover:text-white transition-colors">
                        <Calendar size={14} />
                      </div>
                      <span className="font-bold text-slate-800">{record.date}</span>
                    </div>
                  </td>
                  <td className="px-8 py-6 font-medium text-slate-500">{record.className}</td>
                  <td className="px-8 py-6">
                    <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border ${
                      record.status === 'Present' ? 'bg-green-50 text-green-700 border-green-100' :
                      record.status === 'Absent' ? 'bg-red-50 text-red-700 border-red-100' :
                      'bg-amber-50 text-amber-700 border-amber-100'
                    }`}>
                      {record.status}
                    </span>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <span className="text-[10px] font-medium text-slate-400 italic">
                      {record.status === 'Present' ? 'Wuu joogay' : record.status === 'Late' ? 'Wuu soo daahay' : 'Ma uusan joogin'}
                    </span>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={4} className="px-8 py-20 text-center">
                    <div className="flex flex-col items-center">
                      <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-200 mb-4">
                        <Filter size={32} />
                      </div>
                      <p className="text-slate-400 font-bold uppercase text-xs tracking-widest">Xogtaan wali lama helin</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default StudentAttendanceView;
