
import React, { useState, useEffect } from 'react';
import { Student, AttendanceRecord, ExamResult } from '../../types';
import { StatCard } from '../Shared/StatCard';
import { StatsService } from '../../services/statsService';
import { ClipboardCheck, Star, Award, User, BookOpen, FileCheck, Sparkles, Lightbulb } from 'lucide-react';
import { getLearningAdvice } from '../../services/gemini';

interface StudentViewProps {
  student: Student;
  attendance: AttendanceRecord[];
  results: ExamResult[];
}

const StudentView: React.FC<StudentViewProps> = ({ student, attendance, results }) => {
  const [activeSubTab, setActiveSubTab] = useState<'all' | 'exam' | 'quiz'>('all');
  const [aiAdvice, setAiAdvice] = useState<string>("Dhabac AI ayaa baaraya xogtaada...");
  const [liveStats, setLiveStats] = useState({
    attendancePercentage: 0,
    avgScore: 0,
    assessmentsCount: 0
  });

  const studentResults = results.filter(r => r.studentId === student.id);

  useEffect(() => {
    const fetchLiveData = async () => {
      try {
        const stats = await StatsService.getStudentStats(student.idNumber);
        setLiveStats(stats);

        const advice = await getLearningAdvice(student.name, student.className, {
          results: studentResults.map(r => ({ subject: r.subject, marks: r.marks, grade: r.grade })),
          attendancePercentage: stats.attendancePercentage,
          assessmentsCount: stats.assessmentsCount
        });
        setAiAdvice(advice);
      } catch (err) {
        console.error("Student dashboard fetch error:", err);
      }
    };
    fetchLiveData();
  }, [student, results]);

  const filteredResults = studentResults.filter(r => {
    if (activeSubTab === 'all') return true;
    return r.type.toLowerCase() === activeSubTab;
  });

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-8">
        <div className="w-28 h-28 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl flex items-center justify-center text-white shadow-xl rotate-3 hover:rotate-0 transition-transform duration-300">
          <User size={56} />
        </div>
        <div className="text-center md:text-left flex-1">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">{student.name}</h2>
              <div className="flex flex-wrap justify-center md:justify-start items-center gap-3 mt-2">
                <span className="bg-blue-50 text-blue-700 px-3 py-1 rounded-lg text-xs font-bold border border-blue-100 uppercase tracking-wider">ID: {student.idNumber}</span>
                <span className="bg-indigo-50 text-indigo-700 px-3 py-1 rounded-lg text-xs font-bold border border-indigo-100 uppercase tracking-wider">Class: {student.className}</span>
              </div>
            </div>
            <div className="mt-4 md:mt-0 bg-slate-50 p-4 rounded-2xl border border-slate-100">
              <p className="text-[10px] uppercase font-bold text-slate-400 mb-1">Status</p>
              <span className="flex items-center text-green-600 font-bold text-sm">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                Arday Firfircoon
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-slate-900 to-indigo-950 p-8 rounded-3xl text-white shadow-xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-10 opacity-10 group-hover:scale-110 transition-transform duration-700">
          <Sparkles size={120} />
        </div>
        <div className="relative z-10">
          <div className="flex items-center space-x-3 mb-4">
             <div className="p-2 bg-blue-500/20 rounded-xl backdrop-blur-md">
               <Lightbulb className="text-blue-300" size={20} />
             </div>
             <h3 className="text-xl font-black tracking-tight flex items-center">
               Dhabac AI: Tilmaamaha & Talooyinka
             </h3>
          </div>
          <div className="bg-white/5 backdrop-blur-sm p-6 rounded-2xl border border-white/10 leading-relaxed font-medium text-blue-50 italic">
            {aiAdvice}
          </div>
          <div className="mt-4 flex items-center justify-between">
             <p className="text-[10px] text-blue-300 font-black uppercase tracking-widest">Alnaciim Educational Guide</p>
             <div className="flex items-center text-[10px] text-green-400 font-bold bg-green-400/10 px-2 py-1 rounded-lg">
               <div className="w-1.5 h-1.5 bg-green-400 rounded-full mr-1.5"></div> Analysis Live
             </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard label="Attendance Rate" value={`${liveStats.attendancePercentage}%`} icon={<ClipboardCheck size={24} />} color="bg-blue-600" />
        <StatCard label="Academic Average" value={`${liveStats.avgScore}%`} icon={<Star size={24} />} color="bg-amber-500" />
        <StatCard label="Assessments Done" value={liveStats.assessmentsCount} icon={<Award size={24} />} color="bg-indigo-600" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-indigo-100 text-indigo-700 rounded-lg">
                  <FileCheck size={20} />
                </div>
                <h3 className="text-xl font-bold text-slate-800">Academic Records</h3>
              </div>
              <div className="flex bg-white p-1 rounded-xl border border-slate-200">
                {(['all', 'exam', 'quiz'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveSubTab(tab)}
                    className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-all capitalize ${
                      activeSubTab === tab ? 'bg-blue-900 text-white' : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    {tab}s
                  </button>
                ))}
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50/80 text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100">
                  <tr>
                    <th className="px-8 py-4">Assessment / Subject</th>
                    <th className="px-8 py-4">Type</th>
                    <th className="px-8 py-4">Score</th>
                    <th className="px-8 py-4">Grade</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredResults.length > 0 ? filteredResults.map(result => (
                    <tr key={result.id} className="group hover:bg-slate-50 transition-colors">
                      <td className="px-8 py-5">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center text-blue-600 group-hover:scale-110 transition-transform">
                            <BookOpen size={16} />
                          </div>
                          <div>
                            <p className="font-bold text-slate-800">{result.title || result.subject}</p>
                            <p className="text-[10px] text-slate-400">{result.subject} • {result.date}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-5">
                        <span className={`text-[10px] font-black uppercase px-2 py-1 rounded-md ${
                          result.type === 'Exam' ? 'bg-purple-100 text-purple-700' : 'bg-cyan-100 text-cyan-700'
                        }`}>
                          {result.type}
                        </span>
                      </td>
                      <td className="px-8 py-5">
                        <div className="flex items-center">
                          <span className="text-lg font-black text-slate-700 mr-3">{result.marks}</span>
                          <div className="w-20 h-2 bg-slate-100 rounded-full overflow-hidden">
                            <div 
                              className={`h-full rounded-full transition-all duration-1000 ${
                                result.marks >= 80 ? 'bg-green-500' : result.marks >= 50 ? 'bg-blue-500' : 'bg-red-500'
                              }`}
                              style={{ width: `${(result.marks / result.maxMarks) * 100}%` }}
                            ></div>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-5">
                        <div className="w-10 h-10 rounded-full bg-slate-900 text-white flex items-center justify-center font-black text-sm shadow-lg">
                          {result.grade}
                        </div>
                      </td>
                    </tr>
                  )) : (
                    <tr>
                      <td colSpan={4} className="px-8 py-16 text-center">
                        <div className="flex flex-col items-center">
                          <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center text-slate-300 mb-4">
                            <FileCheck size={32} />
                          </div>
                          <p className="text-slate-400 font-medium">No records found yet.</p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
            <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm uppercase tracking-widest">Attendance Log</h3>
              <ClipboardCheck size={18} className="text-blue-400" />
            </div>
            <div className="p-2">
              {attendance.filter(a => a.studentId === student.id).length > 0 ? attendance.filter(a => a.studentId === student.id).slice(-6).reverse().map((record, idx) => (
                <div key={record.id} className={`flex items-center justify-between p-4 rounded-2xl ${idx !== 0 ? 'mt-1' : ''} hover:bg-slate-50 transition-colors`}>
                  <div>
                    <p className="text-sm font-bold text-slate-800">{record.date}</p>
                    <p className="text-[10px] text-slate-400 font-medium">Daily Class Record</p>
                  </div>
                  <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase ${
                    record.status === 'Present' ? 'bg-green-100 text-green-700' :
                    record.status === 'Absent' ? 'bg-red-100 text-red-700' :
                    'bg-amber-100 text-amber-700'
                  }`}>
                    {record.status}
                  </span>
                </div>
              )) : (
                <div className="p-8 text-center text-slate-400 text-sm italic">
                  No attendance logged.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentView;
