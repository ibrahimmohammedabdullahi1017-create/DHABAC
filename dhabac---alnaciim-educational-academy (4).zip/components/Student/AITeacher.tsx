
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { Send, Sparkles, User, Bot, Loader2, Trash2, AlertCircle, CheckCircle2, Award, Trophy, Star } from 'lucide-react';
import { Student, ExamResult, AttendanceRecord, ReadingMaterial } from '../../types';

interface Message {
  role: 'user' | 'model';
  text: string;
}

interface AITeacherProps {
  student: Student;
  results: ExamResult[];
  attendance: AttendanceRecord[];
  quizLesson: ReadingMaterial | null;
  onQuizSubmit: (result: ExamResult) => void;
}

const AITeacher: React.FC<AITeacherProps> = ({ student, results, attendance, quizLesson, onQuizSubmit }) => {
  const storageKey = `DHABAC_AI_CHAT_${student.idNumber}`;
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isQuizMode, setIsQuizMode] = useState(!!quizLesson);
  const [quizFinished, setQuizFinished] = useState(false);
  const [finalScore, setFinalScore] = useState<{marks: number, grade: string} | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (quizLesson) {
      setIsQuizMode(true);
      setQuizFinished(false);
      setFinalScore(null);
      setMessages([
        { 
          role: 'model', 
          text: `Ascm ${student.name}! Waxaan kuu haynaa imtixaanka casharka: "${quizLesson.title}". \n\nWaxaan ku weydiin doonaa 5 suaalood oo ku saabsan akhriskii laguu soo dhigay. Ma diyaar ayaad u tahay? Qor 'HAA' si aan u bilaabo.` 
        }
      ]);
    } else {
      setIsQuizMode(false);
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        setMessages(JSON.parse(saved));
      } else {
        setMessages([{ role: 'model', text: `Ascm ${student.name}! Waxaan ahay Macallinkaaga AI. Maxaan maanta kaa caawiyaa?` }]);
      }
    }
  }, [quizLesson, student.name]);

  useEffect(() => {
    if (!isQuizMode) {
      localStorage.setItem(storageKey, JSON.stringify(messages));
    }
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [messages, isQuizMode]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: Message = { role: 'user', text: input };
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setInput('');
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
      
      const systemPrompt = isQuizMode 
        ? `You are 'Dhabac AI' testing the student on this lesson: ${quizLesson?.title}.
           CONTENT SUMMARY: ${quizLesson?.contentSummary}.
           RULES:
           1. Ask exactly 5 questions, one at a time.
           2. After 5 questions, use the 'submitScore' tool to grade the student out of 100 based on their accuracy.
           3. Be encouraging and use Af-Soomaali.
           4. If they answer incorrectly, explain why briefly after they answer.
           5. When finished, clearly say 'Imtixaankii waa dhamaaday' and provide their score.
           6. The score should be realistic based on their answers.`
        : `Magacaagu waa 'Dhabac AI' ee ALNACIIM ACADEMY. Ka caawi ardayga natiijadiisa iyo casharadiisa. Luqadda: Af-Soomaali.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: updatedMessages.map(m => ({ role: m.role, parts: [{ text: m.text }] })),
        config: {
          systemInstruction: systemPrompt,
          tools: isQuizMode ? [{
            functionDeclarations: [{
              name: 'submitScore',
              description: 'Submits the final score to the teacher after the quiz is over.',
              parameters: {
                type: Type.OBJECT,
                properties: {
                  marks: { type: Type.NUMBER, description: 'Score out of 100' },
                  grade: { type: Type.STRING, description: 'Grade A-F' }
                },
                required: ['marks', 'grade']
              }
            }]
          }] : []
        }
      });

      if (response.functionCalls && isQuizMode) {
        const call = response.functionCalls[0];
        if (call.name === 'submitScore') {
          const { marks, grade } = call.args as any;
          setFinalScore({ marks, grade });
          
          const finalResult: ExamResult = {
            id: `ai-assignment-${Date.now()}`,
            studentId: student.id,
            subject: 'AI Evaluation',
            title: quizLesson?.title || 'Reading Assignment',
            marks,
            maxMarks: 100,
            grade,
            date: new Date().toISOString().split('T')[0],
            type: 'Assignment' // Categorized as Assignment as per request
          };
          
          onQuizSubmit(finalResult);
          setQuizFinished(true);
        }
      }

      const text = response.text || "Macallinka AI ayaa kaa sugaya jawaabta...";
      setMessages(prev => [...prev, { role: 'model', text }]);
    } catch (error) {
      console.error("AI Error:", error);
      setMessages(prev => [...prev, { role: 'model', text: "Cilad ayaa dhacday. Fadlan mar kale isku day." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-180px)] bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden animate-in fade-in slide-in-from-bottom-4">
      <div className="p-6 bg-blue-900 text-white flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-white/20 rounded-2xl shadow-inner">
            <Sparkles className="text-blue-200" size={24} />
          </div>
          <div>
            <h3 className="font-black text-lg leading-tight">{isQuizMode ? 'Imtixaanka AI' : 'Dhabac AI Guide'}</h3>
            <p className="text-[10px] text-blue-200 font-bold uppercase tracking-widest opacity-80">
              {isQuizMode ? `Casharka: ${quizLesson?.title}` : 'Your Academic Assistant'}
            </p>
          </div>
        </div>
        {quizFinished && (
          <div className="bg-green-500 text-white px-4 py-2 rounded-xl flex items-center text-xs font-black shadow-lg shadow-green-500/20">
            <CheckCircle2 size={16} className="mr-2" /> XOGTA WAA LA KAYDIYAY
          </div>
        )}
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50/30 custom-scrollbar relative">
        {isQuizMode && !quizFinished && (
          <div className="sticky top-0 z-20 bg-indigo-50 border border-indigo-200 p-4 rounded-2xl flex items-start space-x-3 mb-4 shadow-sm animate-pulse">
            <AlertCircle className="text-indigo-600 shrink-0" size={20} />
            <p className="text-sm text-indigo-700 font-medium">Fadlan ha ka bixin boggan ilaa uu AI-gu kuu xaqiijiyo in natiijadaada la xareeyay.</p>
          </div>
        )}

        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`p-4 rounded-2xl max-w-[85%] text-sm shadow-sm ${
              m.role === 'user' 
                ? 'bg-blue-900 text-white rounded-br-none' 
                : 'bg-white text-slate-800 border border-slate-100 rounded-bl-none'
            }`}>
              <div className="whitespace-pre-wrap font-medium">{m.text}</div>
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start">
             <div className="bg-white p-4 rounded-2xl border border-slate-100 flex items-center space-x-3 shadow-sm">
                <Loader2 className="animate-spin text-blue-600" size={18} />
                <span className="text-xs font-bold text-slate-400">AI Teacher is thinking...</span>
             </div>
          </div>
        )}

        {quizFinished && finalScore && (
          <div className="flex justify-center py-8 animate-in zoom-in duration-500">
             <div className="bg-white w-full max-w-sm rounded-[2.5rem] p-8 border border-slate-100 shadow-2xl text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-blue-900 to-indigo-600"></div>
                
                <div className="w-20 h-20 bg-blue-50 text-blue-900 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-blue-900/5 transform rotate-3">
                   <Trophy size={40} />
                </div>
                
                <h4 className="text-2xl font-black text-slate-900 mb-1">Natiijadaada!</h4>
                <p className="text-slate-400 text-xs font-black uppercase tracking-widest mb-6">Reading Assignment</p>
                
                <div className="flex items-center justify-center space-x-6 mb-8">
                   <div className="text-center">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Dhibcaha</p>
                      <p className="text-4xl font-black text-blue-900">{finalScore.marks}%</p>
                   </div>
                   <div className="w-px h-10 bg-slate-100"></div>
                   <div className="text-center">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Darajada</p>
                      <p className="text-4xl font-black text-indigo-600">{finalScore.grade}</p>
                   </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 mb-2">
                   <div className="flex items-center justify-center text-green-600 font-bold text-xs space-x-2">
                      <CheckCircle2 size={14} />
                      <span>Xogta waxaa loo diray Macallinka</span>
                   </div>
                </div>
                <p className="text-[10px] text-slate-400 font-medium">Natiijadaan waxaa lagu kaydiyay diwaanka shaqooyinka (Assignments).</p>
             </div>
          </div>
        )}
      </div>

      {!quizFinished && (
        <div className="p-6 bg-white border-t border-slate-100 shrink-0">
          <form onSubmit={handleSendMessage} className="relative flex items-center">
            <input 
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={isQuizMode ? "Ku qor jawaabtaada halkan..." : "Weydii Macallinka AI su'aal..."}
              className="w-full pl-5 pr-14 py-4 bg-slate-100 border-2 border-transparent focus:border-blue-900 focus:bg-white rounded-2xl text-sm font-bold outline-none transition-all"
              disabled={isLoading}
            />
            <button 
              type="submit" 
              disabled={isLoading || !input.trim()} 
              className={`absolute right-2 p-3 rounded-xl shadow-lg transition-all ${
                isLoading || !input.trim() ? 'bg-slate-200 text-slate-400' : 'bg-blue-900 text-white hover:bg-blue-800'
              }`}
            >
              <Send size={18} />
            </button>
          </form>
          <p className="text-[9px] text-center text-slate-300 font-black uppercase tracking-widest mt-4">Powered by Dhabac Core Engine</p>
        </div>
      )}

      {quizFinished && (
        <div className="p-6 bg-slate-50 border-t border-slate-100 text-center shrink-0">
          <button 
            onClick={() => window.location.reload()} 
            className="text-blue-900 font-black text-xs uppercase tracking-widest hover:underline flex items-center justify-center mx-auto"
          >
             Back to Dashboard <Star size={12} className="ml-2" />
          </button>
        </div>
      )}
    </div>
  );
};

export default AITeacher;
