
import React, { useState, useEffect } from 'react';
import { Teacher, AppState } from '../../types';
import { StatCard } from '../Shared/StatCard';
import { StatsService } from '../../services/statsService';
import { Users, ClipboardCheck, FileCheck, Award, Calendar, ArrowRight } from 'lucide-react';

interface TeacherDashboardProps {
  teacher: Teacher;
  state: AppState;
  onNavigate: (tab: string) => void;
}

const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ teacher, state, onNavigate }) => {
  const [liveStats, setLiveStats] = useState({
    studentCount: 0,
    attRate: 0,
    resultCount: 0
  });

  useEffect(() => {
    const fetchStats = async () => {
      const stats = await StatsService.getTeacherStats(teacher.assignedClasses, teacher.subject);
      setLiveStats(stats);
    };
    fetchStats();
  }, [teacher]);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="bg-gradient-to-r from-blue-900 to-indigo-800 p-10 rounded-3xl text-white shadow-xl flex flex-col lg:flex-row items-center justify-between gap-8 relative overflow-hidden">
        <div className="relative z-10 text-center lg:text-left">
          <h2 className="text-3xl font-black mb-3 tracking-tight">Maalin Wanaagsan, {teacher.name}!</h2>
          <p className="text-blue-100 font-medium opacity-90 text-lg mb-6">
            Maanta waa {new Date().toLocaleDateString('so-SO', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
          <div className="flex flex-wrap justify-center lg:justify-start gap-3">
            {teacher.assignedClasses.map(cls => (
              <span key={cls} className="bg-white/10 backdrop-blur-md px-4 py-2 rounded-xl text-xs font-black border border-white/10 uppercase tracking-widest shadow-sm">
                {cls}
              </span>
            ))}
          </div>
        </div>
        
        <div className="relative z-10 flex flex-col sm:flex-row gap-4 w-full lg:w-auto">
          <button 
            onClick={() => onNavigate('attendance')}
            className="flex-1 lg:flex-none bg-white text-blue-900 px-8 py-4 rounded-2xl font-black shadow-lg hover:bg-blue-50 transform hover:-translate-y-1 transition-all flex items-center justify-center border-2 border-white"
          >
            <ClipboardCheck className="mr-2" size={20} /> Attendance
          </button>
          <button 
            onClick={() => onNavigate('results')}
            className="flex-1 lg:flex-none bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black shadow-lg hover:bg-indigo-500 transform hover:-translate-y-1 transition-all flex items-center justify-center border-2 border-indigo-400/30"
          >
            <FileCheck className="mr-2" size={20} /> Record Marks
          </button>
        </div>
        
        <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none translate-x-10 -translate-y-10">
          <Award size={300} />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center space-x-5 hover:shadow-md transition-shadow group">
          <div className="bg-blue-600 p-4 rounded-2xl text-white group-hover:scale-110 transition-transform shadow-lg shadow-blue-600/20">
            <Users size={28} />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Students</p>
            <p className="text-3xl font-black text-slate-900">{liveStats.studentCount}</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center space-x-5 hover:shadow-md transition-shadow group">
          <div className="bg-emerald-600 p-4 rounded-2xl text-white group-hover:scale-110 transition-transform shadow-lg shadow-emerald-600/20">
            <ClipboardCheck size={28} />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Avg Attendance</p>
            <p className="text-3xl font-black text-slate-900">{liveStats.attRate}%</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center space-x-5 hover:shadow-md transition-shadow group">
          <div className="bg-indigo-600 p-4 rounded-2xl text-white group-hover:scale-110 transition-transform shadow-lg shadow-indigo-600/20">
            <FileCheck size={28} />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Results</p>
            <p className="text-3xl font-black text-slate-900">{liveStats.resultCount}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-black text-slate-900 flex items-center tracking-tight">
              <Calendar className="mr-3 text-blue-900" size={24} />
              Assigned Classes
            </h3>
            <span className="bg-slate-50 text-slate-400 text-[10px] font-black uppercase px-3 py-1 rounded-full border border-slate-100">
              Active Management
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {teacher.assignedClasses.map(clsName => {
              const studentsInClass = state.students.filter(s => s.className === clsName).length;
              return (
                <div key={clsName} className="p-6 bg-slate-50/50 rounded-2xl border border-slate-100 hover:border-blue-200 hover:bg-white transition-all group">
                  <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center text-blue-900 font-black border border-slate-100 mb-4 group-hover:scale-110 transition-transform">
                    {clsName.charAt(0)}
                  </div>
                  <p className="font-black text-slate-800 text-xl mb-1">{clsName}</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-4">{studentsInClass} Students Enrolled</p>
                  <button 
                    onClick={() => onNavigate('attendance')}
                    className="flex items-center text-xs font-black text-blue-600 uppercase tracking-widest group-hover:translate-x-1 transition-transform"
                  >
                    View Class <ArrowRight size={12} className="ml-1" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 flex flex-col justify-center text-center">
          <div className="w-24 h-24 bg-indigo-50 rounded-3xl flex items-center justify-center text-indigo-600 mx-auto mb-6 transform rotate-3">
            <Award size={48} />
          </div>
          <h3 className="text-2xl font-black text-slate-900 mb-2">Academic Overview</h3>
          <p className="text-slate-500 font-medium mb-8 max-w-sm mx-auto leading-relaxed">
            Waxaad hadda maamushaa maaddada <span className="text-indigo-600 font-black">{teacher.subject}</span>. Natiijooyinka la galiyey waxay ka muuqdaan dashboard-ka ardayda.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 flex-1">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Subject Performance</p>
              <p className="text-xl font-black text-indigo-900">Steady</p>
            </div>
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 flex-1">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Completion Rate</p>
              <p className="text-xl font-black text-indigo-900">High</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeacherDashboard;
