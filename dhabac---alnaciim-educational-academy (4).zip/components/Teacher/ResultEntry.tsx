
import React, { useState, useEffect } from 'react';
import { Student, ExamResult } from '../../types';
import { Save, PlusCircle, BookOpen, Tag, Calendar, ChevronDown, Hash, Loader2, CheckCircle2 } from 'lucide-react';

interface ResultEntryProps {
  students: Student[];
  onSave: (results: ExamResult[]) => void;
  className: string;
  teacherSubject: string;
}

const ResultEntry: React.FC<ResultEntryProps> = ({ students, onSave, className, teacherSubject }) => {
  const [assessmentType, setAssessmentType] = useState<'Exam' | 'Quiz' | 'Test'>('Quiz');
  const [assessmentName, setAssessmentName] = useState('');
  const [subject, setSubject] = useState(teacherSubject);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [marks, setMarks] = useState<Record<string, number>>({});
  const [maxMarks, setMaxMarks] = useState(100);
  const [isSaving, setIsSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  // Re-sync marks and subject when students or teacherSubject changes
  useEffect(() => {
    setMarks(Object.fromEntries(students.map(s => [s.id, 0])));
    setSubject(teacherSubject);
  }, [students, teacherSubject]);

  const calculateGrade = (score: number, max: number) => {
    if (max === 0) return 'F';
    const percentage = (score / max) * 100;
    if (percentage >= 90) return 'A+';
    if (percentage >= 80) return 'A';
    if (percentage >= 70) return 'B';
    if (percentage >= 60) return 'C';
    if (percentage >= 50) return 'D';
    return 'F';
  };

  const handleMarkChange = (studentId: string, value: string) => {
    const num = parseInt(value) || 0;
    setMarks(prev => ({ ...prev, [studentId]: Math.min(num, maxMarks) }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!assessmentName.trim()) {
      alert('Fadlan geli magaca qiimaynta (Assessment Name).');
      return;
    }
    if (maxMarks <= 0) {
      alert('Max Marks waa inuu ka weyn yahay 0.');
      return;
    }

    setIsSaving(true);
    // Simulate cloud sync
    await new Promise(resolve => setTimeout(resolve, 1000));

    const newResults: ExamResult[] = students.map(s => ({
      id: Math.random().toString(36).substr(2, 9),
      studentId: s.id,
      subject,
      title: assessmentName,
      marks: marks[s.id] || 0,
      maxMarks,
      grade: calculateGrade(marks[s.id] || 0, maxMarks),
      date,
      type: assessmentType
    }));

    onSave(newResults);
    setIsSaving(false);
    setSuccess(true);
    setAssessmentName('');
    setMarks(Object.fromEntries(students.map(s => [s.id, 0])));

    setTimeout(() => setSuccess(false), 3000);
  };

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="p-8 border-b border-slate-100 bg-slate-50/50">
        <div className="flex flex-col xl:flex-row xl:items-start justify-between gap-8">
          <div className="flex items-center space-x-5">
            <div className="p-4 bg-blue-900 text-white rounded-2xl shadow-xl transform -rotate-2">
              <PlusCircle size={28} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-slate-900 tracking-tight">Xaree Natiijada</h3>
              <p className="text-sm text-slate-500 font-medium">Fasalka: <span className="text-blue-600 font-bold">{className}</span> • Maaddada: <span className="text-indigo-600 font-bold">{subject}</span></p>
            </div>
          </div>
          
          <div className="flex-1 w-full max-w-4xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-3 group hover:border-blue-400 transition-colors">
                  <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    <BookOpen size={20} />
                  </div>
                  <div className="flex-1">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">Assessment Type</p>
                    <div className="relative">
                      <select 
                        value={assessmentType} 
                        onChange={(e) => setAssessmentType(e.target.value as any)}
                        className="w-full text-sm font-black text-slate-800 focus:outline-none bg-transparent appearance-none cursor-pointer pr-8"
                      >
                        <option value="Quiz">Quiz</option>
                        <option value="Exam">Exam</option>
                        <option value="Test">Test</option>
                      </select>
                      <ChevronDown size={16} className="absolute right-0 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                    </div>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-2xl border-2 border-slate-100 shadow-inner flex items-center space-x-4 focus-within:border-blue-500 transition-all">
                  <Tag size={20} className="text-slate-400" />
                  <div className="flex-1">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-0.5">Assessment Name</p>
                    <input 
                      type="text"
                      placeholder="e.g. Midterm Exam, Chapter 3 Quiz"
                      value={assessmentName}
                      onChange={(e) => setAssessmentName(e.target.value)}
                      className="w-full text-sm font-bold text-slate-900 focus:outline-none placeholder:text-slate-300 placeholder:font-normal"
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-3 group hover:border-blue-400 transition-colors">
                  <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                    <Hash size={20} />
                  </div>
                  <div className="flex-1">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">Maximum Possible Marks</p>
                    <input 
                      type="number"
                      min="1"
                      value={maxMarks}
                      onChange={(e) => setMaxMarks(parseInt(e.target.value) || 100)}
                      className="w-full text-sm font-black text-slate-800 focus:outline-none bg-transparent"
                    />
                  </div>
                </div>

                <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-3 group hover:border-blue-400 transition-colors">
                  <div className="p-2.5 bg-amber-50 text-amber-600 rounded-xl group-hover:bg-amber-600 group-hover:text-white transition-colors">
                    <Calendar size={20} />
                  </div>
                  <div className="flex-1">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">Date of Assessment</p>
                    <input 
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full text-sm font-black text-slate-800 focus:outline-none bg-transparent cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-[11px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
              <tr>
                <th className="px-10 py-5">Ardayga (Student Name)</th>
                <th className="px-10 py-5">Dhibcaha (Marks Obtained)</th>
                <th className="px-10 py-5 text-center">Darajada (Grade)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {students.length > 0 ? students.map(student => (
                <tr key={student.id} className="group hover:bg-slate-50 transition-colors">
                  <td className="px-10 py-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 rounded-2xl bg-blue-100 flex items-center justify-center text-blue-700 font-black shadow-sm group-hover:scale-110 transition-transform">
                        {student.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-slate-800 text-base">{student.name}</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">ID: {student.idNumber}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-10 py-6">
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <input 
                          type="number"
                          min="0"
                          max={maxMarks}
                          value={marks[student.id] || 0}
                          onChange={(e) => handleMarkChange(student.id, e.target.value)}
                          className="w-24 px-4 py-3 bg-white border-2 border-slate-200 rounded-xl text-lg font-black text-slate-800 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 focus:outline-none transition-all"
                        />
                        <div className="absolute -top-2 -right-2 bg-slate-900 text-white text-[10px] px-2 py-0.5 rounded-md font-bold">
                          {Math.round(((marks[student.id] || 0) / maxMarks) * 100)}%
                        </div>
                      </div>
                      <span className="text-slate-300 text-xl font-light">/</span>
                      <span className="text-slate-400 font-bold text-lg">{maxMarks}</span>
                    </div>
                  </td>
                  <td className="px-10 py-6">
                    <div className="flex justify-center">
                      <div className={`w-14 h-14 rounded-full flex items-center justify-center font-black text-lg shadow-lg border-4 border-white transition-all duration-500 ${
                        (marks[student.id] || 0) / maxMarks >= 0.8 ? 'bg-green-500 text-white scale-110' :
                        (marks[student.id] || 0) / maxMarks >= 0.5 ? 'bg-blue-600 text-white' :
                        'bg-red-500 text-white'
                      }`}>
                        {calculateGrade(marks[student.id] || 0, maxMarks)}
                      </div>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr>
                   <td colSpan={3} className="px-10 py-20 text-center text-slate-400 font-bold uppercase tracking-widest text-xs">Ma jiraan arday fasalkan ku qoran</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="p-10 bg-slate-50 border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
            <div className="flex items-center p-4 bg-white rounded-2xl border border-slate-200 shadow-sm">
              <div className="p-2 bg-slate-100 rounded-lg mr-3 text-slate-500">
                <BookOpen size={20} />
              </div>
              <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Selected Subject</p>
                <p className="text-sm font-bold text-slate-800">{subject}</p>
              </div>
            </div>
            {success && (
              <div className="flex items-center text-green-600 font-black text-sm animate-bounce">
                <CheckCircle2 size={20} className="mr-2" /> Waa la xareeyay!
              </div>
            )}
          </div>
          
          <button 
            type="submit"
            disabled={isSaving || students.length === 0}
            className={`w-full md:w-auto px-12 py-5 rounded-2xl font-black text-lg shadow-2xl transform transition-all flex items-center justify-center ${
              isSaving 
                ? 'bg-blue-800/80 text-white/50 cursor-wait' 
                : 'bg-blue-900 text-white hover:bg-blue-800 hover:-translate-y-1 active:translate-y-0.5'
            }`}
          >
            {isSaving ? <Loader2 className="mr-3 animate-spin" size={24} /> : <Save className="mr-3" size={24} />}
            {isSaving ? 'Xaraynaya...' : 'Xaree Natiijada (Submit)'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ResultEntry;
