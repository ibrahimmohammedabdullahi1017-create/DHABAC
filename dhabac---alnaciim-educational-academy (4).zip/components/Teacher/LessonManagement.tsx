
import React, { useState, useRef } from 'react';
import { Teacher, ReadingMaterial } from '../../types';
import { BookOpen, Plus, Save, Trash2, X, Link, FileText, Calendar, Upload, FileUp, CheckCircle2 } from 'lucide-react';
import { FileStorageService } from '../../services/fileStorageService';

interface LessonManagementProps {
  teacher: Teacher;
  lessons: ReadingMaterial[];
  onAdd: (lesson: ReadingMaterial) => void;
  onDelete: (id: string) => void;
}

const LessonManagement: React.FC<LessonManagementProps> = ({ teacher, lessons, onAdd, onDelete }) => {
  const [showModal, setShowModal] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    contentSummary: '',
    className: teacher.assignedClasses[0] || ''
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.type !== 'application/pdf') {
        alert('Fadlan soo gali file PDF ah oo kaliya.');
        return;
      }
      setSelectedFile(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      alert('Fadlan dooro file-ka PDF-ka ah ee aad rabto inaad soo galiso.');
      return;
    }

    setIsUploading(true);
    
    try {
      // 1. Generate a clean path for the lesson material
      const fileName = `${Date.now()}_${selectedFile.name.replace(/\s+/g, '_')}`;
      const path = `${teacher.id}/${formData.className.replace(/\s+/g, '_')}/${fileName}`;
      
      // 2. Perform real upload to Supabase Storage
      const publicUrl = await FileStorageService.uploadFile('lessons', path, selectedFile);

      const newLesson: ReadingMaterial = {
        id: `lesson-${Date.now()}`,
        teacherId: teacher.id,
        className: formData.className,
        title: formData.title,
        description: formData.description,
        pdfUrl: publicUrl,
        contentSummary: formData.contentSummary,
        date: new Date().toISOString().split('T')[0]
      };

      onAdd(newLesson);
      setShowModal(false);
      resetForm();
    } catch (err: any) {
      alert('Cilad ayaa dhacday soo gelinta casharka: ' + err.message);
    } finally {
      setIsUploading(false);
    }
  };

  const resetForm = () => {
    setFormData({ title: '', description: '', contentSummary: '', className: teacher.assignedClasses[0] || '' });
    setSelectedFile(null);
  };

  const closeModal = () => {
    setShowModal(false);
    resetForm();
  };

  const teacherLessons = lessons.filter(l => l.teacherId === teacher.id);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-black text-slate-800 tracking-tight">Qorshaha Akhriska</h3>
          <p className="text-sm text-slate-500">Soo gali casharada (PDF) si ardaydu u akhriyaan, AI-guna u weydiiyo.</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-blue-900 text-white px-6 py-3 rounded-2xl font-black text-sm flex items-center shadow-lg hover:bg-blue-800 transition-all active:scale-95"
        >
          <Plus size={18} className="mr-2" /> Cashar Cusub
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {teacherLessons.length > 0 ? teacherLessons.map(lesson => (
          <div key={lesson.id} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all group relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-blue-50/50 rounded-full -mr-10 -mt-10 pointer-events-none"></div>
            
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-blue-900 text-white rounded-2xl shadow-lg shadow-blue-900/10">
                <FileText size={24} />
              </div>
              <button 
                onClick={() => {
                  if(window.confirm('Ma hubtaa inaad tirtirto casharkan?')) onDelete(lesson.id);
                }} 
                className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
              >
                <Trash2 size={16} />
              </button>
            </div>
            
            <h4 className="text-lg font-black text-slate-800 mb-1">{lesson.title}</h4>
            <div className="flex items-center space-x-2 mb-3">
              <span className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-widest border border-blue-100">
                {lesson.className}
              </span>
            </div>
            
            <p className="text-sm text-slate-500 line-clamp-2 mb-6 font-medium">{lesson.description}</p>
            
            <div className="flex items-center justify-between pt-4 border-t border-slate-50">
              <div className="flex items-center text-[10px] font-black text-slate-400 uppercase tracking-tighter">
                <Calendar size={12} className="mr-1.5 text-blue-400" /> {lesson.date}
              </div>
              <a 
                href={lesson.pdfUrl} 
                target="_blank" 
                rel="noreferrer" 
                className="text-blue-900 font-black text-[10px] uppercase hover:underline flex items-center bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100"
              >
                Furi PDF <Link size={10} className="ml-1.5" />
              </a>
            </div>
          </div>
        )) : (
          <div className="col-span-full py-24 bg-white rounded-[2.5rem] border-2 border-dashed border-slate-100 text-center flex flex-col items-center">
            <div className="w-20 h-20 bg-slate-50 rounded-3xl flex items-center justify-center text-slate-200 mb-6">
              <BookOpen size={48} />
            </div>
            <h4 className="text-xl font-black text-slate-800 tracking-tight">Wali cashar ma jiro</h4>
            <p className="text-slate-400 font-medium max-w-xs mx-auto mt-2">
              Soo gali PDF-yada ardaydaadu akhrinayaan si aad u bilowdo nidaamka AI-ga.
            </p>
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-xl rounded-[2.5rem] shadow-2xl flex flex-col max-h-[90vh] overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="p-6 md:p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50 shrink-0">
              <div className="flex items-center space-x-4">
                 <div className="p-3 bg-blue-900 text-white rounded-2xl shadow-lg">
                   <FileUp size={24} />
                 </div>
                 <h3 className="text-xl md:text-2xl font-black text-slate-800 tracking-tight">Soo Gali Cashar PDF ah</h3>
              </div>
              <button onClick={closeModal} className="text-slate-400 hover:text-slate-600 bg-white p-2 rounded-xl border border-slate-200 shadow-sm transition-all active:scale-95"><X size={20} /></button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 md:p-8 space-y-6 overflow-y-auto custom-scrollbar flex-1">
              <div className="grid grid-cols-2 gap-4 md:gap-6">
                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2.5 ml-1">Ciwaanka Casharka</label>
                  <input 
                    type="text" required
                    placeholder="Tusaale: Taariikhda Soomaaliya"
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all outline-none"
                    value={formData.title}
                    onChange={e => setFormData({...formData, title: e.target.value})}
                  />
                </div>
                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2.5 ml-1">Fasalka loogu talagalay</label>
                  <select 
                    className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold appearance-none cursor-pointer focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all outline-none"
                    value={formData.className}
                    onChange={e => setFormData({...formData, className: e.target.value})}
                  >
                    {teacher.assignedClasses.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2.5 ml-1">Soo xulo File-ka PDF-ka ah</label>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-3xl p-6 md:p-8 text-center cursor-pointer transition-all ${
                    selectedFile ? 'border-green-500 bg-green-50/30' : 'border-slate-200 bg-slate-50 hover:border-blue-400 hover:bg-blue-50/30'
                  }`}
                >
                  <input 
                    type="file" 
                    accept=".pdf" 
                    className="hidden" 
                    ref={fileInputRef}
                    onChange={handleFileChange}
                  />
                  {selectedFile ? (
                    <div className="flex flex-col items-center animate-in zoom-in">
                      <CheckCircle2 size={40} className="text-green-500 mb-3" />
                      <p className="font-bold text-slate-800 text-sm">{selectedFile.name}</p>
                      <p className="text-[10px] text-slate-400 font-black uppercase mt-1">Ready to upload • {(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center">
                      <Upload size={40} className="text-slate-300 mb-3 group-hover:text-blue-500 transition-colors" />
                      <p className="font-bold text-slate-600 text-sm">Guji halkan si aad u soo xulato PDF</p>
                      <p className="text-[10px] text-slate-400 font-black uppercase mt-1 tracking-widest">Waa inuu ahaadaa .pdf oo kaliya</p>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2.5 ml-1">Sharaxaad kooban oo ardayga loogu talagalay</label>
                <textarea 
                  placeholder="Maxay tahay waxa ay ardaydu baran doonaan?"
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all outline-none"
                  rows={2}
                  value={formData.description}
                  onChange={e => setFormData({...formData, description: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2.5 ml-1">Xog muhiim ah (Si uu AI-gu u fahmo)</label>
                <textarea 
                  placeholder="Ku qor halkan qodobbada muhiimka ah ee ku jira PDF-ka si Macallin AI u weydiiyo ardayga..."
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold focus:ring-4 focus:ring-blue-500/5 focus:border-blue-500 transition-all outline-none"
                  rows={3}
                  value={formData.contentSummary}
                  onChange={e => setFormData({...formData, contentSummary: e.target.value})}
                />
              </div>

              <div className="pt-2">
                <button 
                  type="submit"
                  disabled={isUploading || !selectedFile}
                  className={`w-full py-5 rounded-2xl font-black shadow-xl transition-all flex items-center justify-center ${
                    isUploading 
                      ? 'bg-blue-800/80 text-white/50 cursor-wait' 
                      : 'bg-blue-900 text-white hover:bg-blue-800 hover:-translate-y-1 active:translate-y-0.5'
                  }`}
                >
                  {isUploading ? (
                    <div className="flex items-center">
                      <div className="w-5 h-5 border-4 border-white/20 border-t-white rounded-full animate-spin mr-3"></div>
                      Kaydinaya Supabase Storage...
                    </div>
                  ) : (
                    <>
                      <Save size={20} className="mr-3" /> Kaydi oo soo Daabac
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default LessonManagement;
