
import { supabase, isSupabaseConfigured } from './supabase';
import { ExamResult } from '../types';

export class QuizService {
  /**
   * Evaluates and grades a student's quiz attempt.
   */
  static evaluateAttempt(questions: any[], answers: number[]): { marks: number, grade: string } {
    let score = 0;
    questions.forEach((q, idx) => {
      if (answers[idx] === q.correctOptionIndex) score += 20; // Assuming 5 questions @ 20pts
    });

    let grade = 'F';
    if (score >= 90) grade = 'A+';
    else if (score >= 80) grade = 'A';
    else if (score >= 70) grade = 'B';
    else if (score >= 50) grade = 'C';

    return { marks: score, grade };
  }

  /**
   * Saves the result of an AI Assignment or Quiz to the DB.
   */
  static async submitResult(result: ExamResult) {
    if (!isSupabaseConfigured) return;

    const { error } = await supabase.from('results').insert({
      student_id: result.studentId,
      subject: result.subject,
      title: result.title,
      marks: result.marks,
      max_marks: result.maxMarks,
      grade: result.grade,
      date: result.date,
      type: result.type
    });

    if (error) throw error;
  }
}
