
import { supabase, isSupabaseConfigured } from './supabase';
import { UserRole, Student, Teacher, User } from '../types';
import { INITIAL_STUDENTS, INITIAL_TEACHERS } from '../constants';

export class AuthService {
  private static mapIdToEmail(id: string): string {
    if (id.includes('@')) return id;
    return `${id.toLowerCase()}@alnaciim.edu`;
  }

  private static mapProfileToUser(profile: any): any {
    return {
      id: profile.id_number,
      db_id: profile.id,
      name: profile.name,
      role: profile.role as UserRole,
      className: profile.class_name,
      subject: profile.subject,
      assignedClasses: profile.assigned_classes || [],
      status: profile.status,
      avatar: profile.avatar,
      password: profile.password
    };
  }

  static async signIn(idNumber: string, password: string) {
    if (!isSupabaseConfigured) {
      if (idNumber === 'admin' && password === 'admin') {
        return { profile: { id: 'admin', name: 'Super Admin', role: UserRole.ADMIN } as any };
      }
      const teacher = INITIAL_TEACHERS.find(t => t.id === idNumber && t.password === password);
      if (teacher) return { profile: teacher };
      const student = INITIAL_STUDENTS.find(s => s.idNumber === idNumber && s.password === password);
      if (student) return { profile: student };
      throw new Error('Invalid credentials (Offline Mode)');
    }

    try {
      // 1. Check if profile exists first (The "Registration" check)
      const { data: profileCheck, error: checkError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id_number', idNumber)
        .maybeSingle();

      if (checkError) throw checkError;

      // Special case for Super Admin
      if (idNumber === 'admin' && profileCheck?.password === password) {
        return { auth: null, profile: this.mapProfileToUser(profileCheck) };
      }

      if (!profileCheck) {
        throw new Error('ID Number-kan ma diwaangashana. Fadlan is diwaangeli ama la xariir maamulka.');
      }

      // 2. Try Auth Login
      const email = this.mapIdToEmail(idNumber);
      const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (!authError && authData.user) {
        if (profileCheck.role === UserRole.STUDENT && profileCheck.status !== 'approved') {
          await supabase.auth.signOut();
          throw new Error(profileCheck.status === 'pending' ? 'Codsigaaga wali waa la sugayaa.' : 'Codsigaaga waa la diiday.');
        }
        return { auth: authData.user, profile: this.mapProfileToUser(profileCheck) };
      }

      // 3. Manual Pass Check (Fallback for IDs added directly to table without Auth signup)
      if (profileCheck.password === password) {
        if (profileCheck.role === UserRole.STUDENT && profileCheck.status !== 'approved') {
          throw new Error(profileCheck.status === 'pending' ? 'Codsigaaga wali waa la sugayaa.' : 'Codsigaaga waa la diiday.');
        }
        return { auth: null, profile: this.mapProfileToUser(profileCheck) };
      }

      throw new Error('Password-kaagu waa khalad.');
    } catch (err: any) {
      throw new Error(err.message || 'Cilad ayaa dhacday soo gelitaanka.');
    }
  }

  static async signOut() {
    if (isSupabaseConfigured) {
      await supabase.auth.signOut();
    }
  }

  static async getCurrentUser() {
    if (!isSupabaseConfigured) return null;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return null;

      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', session.user.id)
        .maybeSingle();

      if (!profile) return null;
      return this.mapProfileToUser(profile);
    } catch (err) {
      return null;
    }
  }

  static async signUp(data: { name: string; idNumber: string; className: string; password: string; role: UserRole; status?: string }) {
    if (!isSupabaseConfigured) throw new Error('Cloud auth not configured.');

    const email = this.mapIdToEmail(data.idNumber);
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password: data.password,
    });

    if (authError) throw authError;
    if (!authData.user) throw new Error('Auth failed.');

    const finalStatus = data.status || (data.role === UserRole.STUDENT ? 'pending' : 'approved');

    const profilePayload = {
      id: authData.user.id,
      id_number: data.idNumber,
      name: data.name,
      role: data.role,
      class_name: data.className,
      password: data.password,
      status: finalStatus,
    };

    const { error: profileError } = await supabase.from('profiles').insert(profilePayload);
    if (profileError) throw profileError;
    
    return {
      auth: authData.user,
      profile: this.mapProfileToUser(profilePayload)
    };
  }
}
