
import { supabase, isSupabaseConfigured } from './supabase';
import { UserRole } from '../types';

export class StatsService {
  static async getAdminStats() {
    if (!isSupabaseConfigured) return { studentCount: 0, teacherCount: 0, classCount: 0, avgAttendance: '0%' };

    try {
      const { count: studentCount } = await supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('role', UserRole.STUDENT).eq('status', 'approved');
      const { count: teacherCount } = await supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('role', UserRole.TEACHER);
      const { count: classCount } = await supabase.from('classes').select('*', { count: 'exact', head: true });
      
      const { data: attData } = await supabase.from('attendance').select('status');
      const total = attData?.length || 0;
      const present = attData?.filter(a => a.status === 'Present' || a.status === 'Late').length || 0;
      const rate = total > 0 ? Math.round((present / total) * 100) : 0;

      return {
        studentCount: studentCount || 0,
        teacherCount: teacherCount || 0,
        classCount: classCount || 0,
        avgAttendance: `${rate}%`
      };
    } catch (err) {
      return { studentCount: 0, teacherCount: 0, classCount: 0, avgAttendance: '0%' };
    }
  }

  static async getTeacherStats(assignedClasses: string[], subject: string) {
    if (!isSupabaseConfigured || !assignedClasses.length) return { studentCount: 0, attRate: 0, resultCount: 0 };

    try {
      const { count: studentCount } = await supabase.from('profiles').select('*', { count: 'exact', head: true }).in('class_name', assignedClasses).eq('status', 'approved');
      const { data: attData } = await supabase.from('attendance').select('status').in('class_name', assignedClasses);
      const total = attData?.length || 0;
      const present = attData?.filter(a => a.status === 'Present').length || 0;
      const attRate = total > 0 ? Math.round((present / total) * 100) : 0;

      const { count: resultCount } = await supabase.from('results').select('*', { count: 'exact', head: true }).eq('subject', subject);

      return { studentCount: studentCount || 0, attRate, resultCount: resultCount || 0 };
    } catch (err) {
      return { studentCount: 0, attRate: 0, resultCount: 0 };
    }
  }

  static async getStudentStats(studentId: string) {
    if (!isSupabaseConfigured) return { attendancePercentage: 0, avgScore: 0, assessmentsCount: 0 };

    try {
      const { data: attData } = await supabase.from('attendance').select('status').eq('student_id', studentId);
      const total = attData?.length || 0;
      const present = attData?.filter(a => a.status === 'Present').length || 0;
      
      const { data: resData } = await supabase.from('results').select('marks, max_marks').eq('student_id', studentId);
      const avg = resData?.length ? Math.round(resData.reduce((acc, r) => acc + (r.marks / r.max_marks * 100), 0) / resData.length) : 0;

      return {
        attendancePercentage: total > 0 ? Math.round((present / total) * 100) : 0,
        avgScore: avg,
        assessmentsCount: resData?.length || 0
      };
    } catch (err) {
      return { attendancePercentage: 0, avgScore: 0, assessmentsCount: 0 };
    }
  }
}
