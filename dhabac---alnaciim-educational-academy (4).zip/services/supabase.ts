
import { createClient } from '@supabase/supabase-js';

// Safely access process.env to prevent ReferenceErrors in environments where process is not defined
const getEnv = (key: string) => {
  try {
    return process.env[key];
  } catch (e) {
    return undefined;
  }
};

const supabaseUrl = getEnv('VITE_SUPABASE_URL') || getEnv('SUPABASE_URL') || 'https://placeholder-url.supabase.co';
const supabaseKey = getEnv('VITE_SUPABASE_ANON_KEY') || getEnv('SUPABASE_ANON_KEY') || 'placeholder-anon-key';

/**
 * Checks if the Supabase configuration is valid and not placeholders.
 */
export const isSupabaseConfigured = 
  supabaseUrl !== 'https://placeholder-url.supabase.co' && 
  supabaseKey !== 'placeholder-anon-key';

// Initialize the real Supabase client
export const supabase = createClient(supabaseUrl, supabaseKey);
