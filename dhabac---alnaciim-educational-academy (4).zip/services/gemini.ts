
import { GoogleGenAI } from "@google/genai";

export async function getPerformanceSummary(data: any) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analyse this school data and provide a professional 3-sentence summary of the current academic status for ALNACIIM ACADEMY. Data: ${JSON.stringify(data)}`,
      config: {
        systemInstruction: "You are an expert educational consultant for ALNACIIM ACADEMY. Be professional, data-driven, and encouraging."
      }
    });
    
    return response.text || "Academic summary is currently being updated.";
  } catch (error) {
    console.error("AI Performance Summary Error:", error);
    return "Xogta dashboard-ka ayaa la diyaarinayaa...";
  }
}

export async function getLearningAdvice(studentName: string, className: string, performanceData: any) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Student: ${studentName}, Class: ${className}. Performance: ${JSON.stringify(performanceData)}. 
      Identify specific mistakes (low scores or poor attendance) and provide 3 actionable tips in Somali to help them improve.`,
      config: {
        systemInstruction: "You are 'Dhabac AI', the official mentor at ALNACIIM ACADEMY. Your job is to be an 'Educational Guide'. Focus on pointing out where the student is failing and provide encouraging, constructive feedback in Somali (Af-Soomaali). Be specific about subjects where scores are low."
      }
    });

    return response.text || "Macallinka AI ayaa hadda diyaarinaya talooyinkaada...";
  } catch (error) {
    console.error("AI Learning Advice Error:", error);
    return "Wali xogtaada ayaa la baarayaa...";
  }
}
