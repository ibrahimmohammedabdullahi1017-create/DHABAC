
import { supabase, isSupabaseConfigured } from './supabase';
import { AttendanceRecord } from '../types';

export class AttendanceService {
  static async saveBatch(records: AttendanceRecord[]) {
    if (!records.length || !isSupabaseConfigured) return;

    const payload = records.map(r => ({
      student_id: r.studentId,
      student_name: r.studentName,
      date: r.date,
      status: r.status,
      class_name: r.className
    }));

    const { error } = await supabase
      .from('attendance')
      .upsert(payload, { onConflict: 'student_id,date' });

    if (error) throw error;
  }

  static async updateStatus(id: string, status: string) {
    if (!isSupabaseConfigured) return;
    await supabase.from('attendance').update({ status }).eq('id', id);
  }

  static async delete(id: string) {
    if (!isSupabaseConfigured) return;
    await supabase.from('attendance').delete().eq('id', id);
  }
}
