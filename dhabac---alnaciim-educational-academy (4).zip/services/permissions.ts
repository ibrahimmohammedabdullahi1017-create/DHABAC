
import { UserRole } from '../types';

/**
 * Maps system tab IDs to the roles allowed to access them.
 * This acts as the source of truth for the Role Guard.
 */
export const TAB_PERMISSIONS: Record<string, UserRole[]> = {
  dashboard: [UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT],
  registrations: [UserRole.ADMIN],
  admins: [UserRole.ADMIN],
  reading: [UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT],
  'ai-teacher': [UserRole.STUDENT],
  students: [UserRole.ADMIN, UserRole.TEACHER],
  teachers: [UserRole.ADMIN],
  classes: [UserRole.ADMIN],
  attendance: [UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT],
  results: [UserRole.ADMIN, UserRole.TEACHER, UserRole.STUDENT],
  backup: [UserRole.ADMIN],
  settings: [UserRole.ADMIN],
  album: [UserRole.ADMIN]
};

/**
 * Helper to check if a specific role is authorized for a tab.
 */
export const isTabAuthorized = (tabId: string, role: UserRole): boolean => {
  const allowedRoles = TAB_PERMISSIONS[tabId];
  if (!allowedRoles) return true; // Default to public or dashboard if tab is unknown
  return allowedRoles.includes(role);
};
