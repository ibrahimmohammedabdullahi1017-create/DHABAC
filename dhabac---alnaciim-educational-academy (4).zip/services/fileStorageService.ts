
import { supabase, isSupabaseConfigured } from './supabase';

export class FileStorageService {
  /**
   * Uploads a file to a specific Supabase bucket.
   */
  static async uploadFile(bucket: string, path: string, file: File): Promise<string> {
    if (!isSupabaseConfigured) {
      return URL.createObjectURL(file); // Temporary URL for offline testing
    }

    try {
      const { data, error } = await supabase.storage
        .from(bucket)
        .upload(path, file, { upsert: true });

      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage
        .from(bucket)
        .getPublicUrl(data.path);

      return publicUrl;
    } catch (err: any) {
      throw new Error(`File upload failed: ${err.message}`);
    }
  }
}
