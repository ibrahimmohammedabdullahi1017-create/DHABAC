
import { supabase, isSupabaseConfigured } from './supabase';
import { User, UserRole } from '../types';
import { FileStorageService } from './fileStorageService';

export class ProfileService {
  /**
   * Creates a new profile record in the database. 
   * Used by Admins to manually add students/teachers.
   */
  static async createProfile(data: {
    idNumber: string,
    name: string,
    role: UserRole,
    className?: string,
    subject?: string,
    password?: string,
    status?: string
  }, avatarFile?: File) {
    let avatarUrl = '';

    if (avatarFile) {
      const extension = avatarFile.name.split('.').pop();
      const path = `avatars/${data.idNumber}_${Date.now()}.${extension}`;
      avatarUrl = await FileStorageService.uploadFile('avatars', path, avatarFile);
    }

    if (!isSupabaseConfigured) return avatarUrl;

    const { error } = await supabase
      .from('profiles')
      .insert({
        id_number: data.idNumber,
        name: data.name,
        role: data.role,
        class_name: data.className || null,
        subject: data.subject || null,
        avatar: avatarUrl || null,
        status: data.status || 'approved',
        // Note: In a real app, password should be handled via Auth Admin API
        // For this implementation, we store it in the profile for easy management
        password: data.password || '123' 
      });

    if (error) {
      if (error.code === '23505') throw new Error('ID Number-kan horay ayaa loo diwaangeliyay.');
      throw error;
    }
    
    return avatarUrl;
  }

  /**
   * Updates user profile data and optionally uploads a new avatar.
   */
  static async updateProfile(
    userId: string, 
    updates: Partial<User & { className?: string, subject?: string, avatar?: string }>,
    avatarFile?: File
  ) {
    let avatarUrl = updates.avatar || '';

    if (avatarFile) {
      const extension = avatarFile.name.split('.').pop();
      const path = `avatars/${userId}_${Date.now()}.${extension}`;
      avatarUrl = await FileStorageService.uploadFile('avatars', path, avatarFile);
    }

    if (!isSupabaseConfigured) return avatarUrl;

    const { error } = await supabase
      .from('profiles')
      .update({
        name: updates.name,
        class_name: updates.className,
        subject: updates.subject,
        avatar: avatarUrl,
      })
      .eq('id_number', userId);

    if (error) throw error;
    return avatarUrl;
  }

  static async convertToBase64(file: File): Promise<string> {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.readAsDataURL(file);
    });
  }
}
