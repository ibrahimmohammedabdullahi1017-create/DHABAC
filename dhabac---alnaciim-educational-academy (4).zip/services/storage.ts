
import { AppState, UserRole, Student, Teacher, AttendanceRecord, ExamResult, ReadingMaterial, Quiz } from '../types';
import { INITIAL_STUDENTS, INITIAL_TEACHERS, INITIAL_CLASSES, MOCK_RESULTS } from '../constants';
import { supabase, isSupabaseConfigured } from './supabase';

const STORAGE_KEY = 'DHABAC_DATA';

export class SchoolStorage {
  static async save(state: AppState) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      if (isSupabaseConfigured) {
        this.syncToCloud(state).catch(() => {});
      }
    } catch (e) {
      console.error('Save failed', e);
    }
  }

  private static async syncToCloud(state: AppState) {
    try {
      await supabase.from('settings').upsert({
        id: 1,
        school_name: state.settings.schoolName,
        system_name: state.settings.systemName,
        primary_color: state.settings.primaryColor,
        secondary_color: state.settings.secondaryColor,
        logo_url: state.settings.logoUrl
      });
    } catch (err) {}
  }

  static load(): AppState {
    const defaultSettings = {
      schoolName: 'ALNACIIM EDUCATIONAL ACADEMY',
      systemName: 'DHABAC',
      primaryColor: '#1e3a8a',
      secondaryColor: '#3b82f6',
      logoUrl: ''
    };

    const emptyState: AppState = {
      users: [],
      students: INITIAL_STUDENTS,
      teachers: INITIAL_TEACHERS,
      classes: INITIAL_CLASSES,
      attendance: [],
      results: MOCK_RESULTS,
      lessons: [],
      quizzes: [],
      settings: defaultSettings,
      currentUser: null,
    };

    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...emptyState,
          ...parsed,
          settings: parsed.settings || defaultSettings,
          lessons: parsed.lessons || [],
          quizzes: parsed.quizzes || [],
        };
      }
    } catch (e) {
      console.error("Failed to load local storage", e);
    }

    return emptyState;
  }
}
